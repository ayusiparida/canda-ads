// Build the demo: add everyone in data/people.csv, analyze them, then run a full dating season.
// Usage: node scripts/seed.js [path/to/people.csv]
import fs from "node:fs";
import { addPerson, readAndAnalyze, runSeason } from "../src/pipeline.js";
import { pool } from "../src/util.js";
import { config } from "../src/config.js";
import { stats } from "../src/llm.js";
import { db } from "../src/db.js";

const file = process.argv[2] || "data/people.csv";
const rows = fs.readFileSync(file, "utf8").split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith("#") && !/^linkedin/i.test(l));
console.log(`Seeding ${rows.length} people from ${file} (llm=${config.llmProvider}, linkedin=${config.linkedinProvider}, instagram=${config.instagramProvider})`);

const ids = [];
for (const line of rows) {
  const [linkedin, instagram, gender = "", open_to = "anyone"] = line.split(",").map((s) => s.trim());
  try { ids.push(addPerson({ linkedin, instagram, gender, open_to, is_demo: 1 }).id); }
  catch (e) { console.error(`  skip: ${line}\n    ${e.message}`); }
}
const t0 = Date.now();
const results = await pool(ids, Math.max(2, Math.floor(config.llmConcurrency / 2)), async (id) => {
  const ok = await readAndAnalyze(id);
  const p = db.prepare("SELECT name, status, error FROM people WHERE id=?").get(id);
  console.log(`  ${ok ? "✓" : "✗"} ${p.name || id} ${p.error ? `- ${p.error}` : ""}`);
  return ok;
});
const ready = ids.filter((_, i) => results[i] === true);
console.log(`Analyzed ${ready.length}/${ids.length} in ${((Date.now() - t0) / 1000).toFixed(0)}s. Starting the dating season…`);
const demoIds = db.prepare("SELECT id FROM people WHERE is_demo=1").all().map((r) => r.id);
const n = await runSeason(demoIds);
const done = db.prepare("SELECT COUNT(*) n FROM dates WHERE status='done'").get().n;
console.log(`Season done: ${done}/${n} dates finished. LLM calls: ${stats.calls}, tokens in/out: ${stats.inputTokens}/${stats.outputTokens}. Total ${((Date.now() - t0) / 1000).toFixed(0)}s.`);
process.exit(0);
