# 3-minute video script

Record the deployed site at 1280px wide. Run the demo season beforehand; open one date live in a second tab.

| Time | On screen | Say |
|---|---|---|
| 0:00–0:15 | Home page | "Every person gets an AI agent that only knows their LinkedIn and public Instagram. The agents date each other and rank who fits best." |
| 0:15–0:35 | Paste a LinkedIn + Instagram, tick consent, Send the agent out. Profile page shows "Reading their links", then "Agent is analyzing". | "Links go in. The agent reads exactly these two sources." |
| 0:35–1:10 | A finished demo profile. Scroll: verification badge → How the agent read them (click one IG:post tag to jump to the source post) → Needs / Hobbies / Interests / Values / Personality → lifestyle, green flags, friction → open the agent brief. | "Every claim cites the post or role it came from. This is the brief the agent dates with." |
| 1:10–2:05 | Dates page, then one full date. Read the venue, scroll the chat, point at private thoughts, the unscripted moment, then both debriefs with different scores and the needs check. Show a live date streaming in. | "A planner picks a venue both would like. They talk turn by turn, each thinking privately. Halfway, something unscripted happens. Then each agent reports back to its own person." |
| 2:05–2:40 | Rankings page: strongest mutual matches, everyone's top 5. Open one person's ranking with reasons and a link to the date. | "Fit needs both sides: the geometric mean of both debriefs, plus a bonus if both want a second date." |
| 2:40–3:00 | Back to the newcomer from 0:15, now Ranked, with their 5 dates and ranking. | "That's the whole loop, from links to rankings. Demo and live site links are below." |
