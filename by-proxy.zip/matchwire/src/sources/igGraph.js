import { config } from "../config.js";
// Official route: Instagram Graph API "Business Discovery". Works for public Business/Creator
// accounts, queried through your own IG professional account + Meta app token.
export async function fetchInstagram(handle) {
  if (!config.igGraphToken || !config.igGraphUserId) throw new Error("IG_GRAPH_TOKEN and IG_GRAPH_USER_ID are required for the graph provider.");
  const fields = `business_discovery.username(${handle}){username,name,biography,website,followers_count,follows_count,media_count,profile_picture_url,media.limit(30){caption,media_url,media_type,permalink,timestamp,like_count}}`;
  const url = `https://graph.facebook.com/v21.0/${config.igGraphUserId}?fields=${encodeURIComponent(fields)}&access_token=${config.igGraphToken}`;
  const res = await fetch(url);
  const body = await res.json();
  if (!res.ok || !body.business_discovery) {
    throw new Error(`Instagram Graph API could not read @${handle}. It only works for public Business or Creator accounts.`);
  }
  const b = body.business_discovery;
  return {
    handle: b.username.toLowerCase(), name: b.name || "", bio: b.biography || "", externalUrl: b.website || "",
    followers: b.followers_count, following: b.follows_count, postsCount: b.media_count, isPrivate: false,
    verified: false, category: "", photo: b.profile_picture_url || "",
    posts: (b.media?.data || []).map((m) => ({
      caption: m.caption || "", hashtags: (m.caption || "").match(/#[\p{L}\d_]+/gu)?.map((h) => h.slice(1)) || [],
      location: "", timestamp: m.timestamp, likes: m.like_count ?? null, type: m.media_type,
      imageUrl: m.media_type === "VIDEO" ? "" : m.media_url, url: m.permalink,
    })),
  };
}
