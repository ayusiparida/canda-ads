import { config } from "../config.js";

// Runs an Apify actor synchronously and returns its dataset items.
async function runActor(actor, input, timeoutSecs = 180) {
  if (!config.apifyToken) throw new Error("APIFY_TOKEN is not set.");
  const url = `https://api.apify.com/v2/acts/${actor}/run-sync-get-dataset-items?timeout=${timeoutSecs}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${config.apifyToken}` },
    body: JSON.stringify(input),
  });
  if (!res.ok) throw new Error(`Apify ${actor} failed (${res.status}): ${(await res.text()).slice(0, 200)}`);
  return res.json();
}

const first = (...v) => v.find((x) => x !== undefined && x !== null && x !== "");
const arr = (x) => (Array.isArray(x) ? x : []);

export async function fetchInstagram(handle) {
  const items = await runActor(config.apifyInstagramActor, { usernames: [handle], resultsLimit: 30 });
  const p = items?.[0];
  if (!p || p.error) throw new Error(`Instagram profile @${handle} was not found.`);
  return {
    handle: (p.username || handle).toLowerCase(),
    name: p.fullName || "",
    bio: p.biography || "",
    externalUrl: first(p.externalUrl, arr(p.externalUrls)[0]?.url, ""),
    followers: p.followersCount ?? null,
    following: p.followsCount ?? null,
    postsCount: p.postsCount ?? null,
    isPrivate: !!p.private,
    verified: !!p.verified,
    category: p.businessCategoryName || "",
    photo: first(p.profilePicUrlHD, p.profilePicUrl, ""),
    posts: arr(p.latestPosts).slice(0, 30).map((x) => ({
      caption: x.caption || "",
      hashtags: arr(x.hashtags),
      location: x.locationName || "",
      timestamp: x.timestamp || "",
      likes: x.likesCount ?? null,
      type: x.type || "",
      imageUrl: x.displayUrl || "",
      url: x.url || "",
    })),
  };
}

export async function fetchLinkedin(slug, url) {
  const items = await runActor(config.apifyLinkedinActor, { profileUrls: [url] });
  const p = items?.[0];
  if (!p || p.error || (!p.fullName && !p.firstName)) throw new Error(`LinkedIn profile /in/${slug} was not found or is not public.`);
  const exp = arr(first(p.experiences, p.experience, p.positions));
  const edu = arr(first(p.educations, p.education));
  return {
    url,
    name: first(p.fullName, [p.firstName, p.lastName].filter(Boolean).join(" ")),
    headline: p.headline || "",
    location: first(p.addressWithCountry, p.location, p.addressWithoutCountry, ""),
    about: first(p.about, p.summary, ""),
    photo: first(p.profilePicHighQuality, p.profilePic, p.profilePicture, ""),
    experience: exp.slice(0, 12).map((e) => ({
      title: first(e.title, e.position, ""),
      company: first(e.companyName, e.subtitle, e.company, "").split("·")[0].trim(),
      dates: first(e.caption, e.dateRange, e.duration, ""),
      description: arr(e.subComponents).flatMap((s) => arr(s.description).map((d) => d.text)).join(" ") || e.description || "",
    })),
    education: edu.slice(0, 6).map((e) => ({
      school: first(e.title, e.schoolName, e.school, ""),
      degree: first(e.subtitle, e.degree, ""),
      dates: first(e.caption, e.dateRange, ""),
    })),
    skills: arr(p.skills).map((s) => (typeof s === "string" ? s : s.title || s.name)).filter(Boolean).slice(0, 30),
    posts: arr(first(p.updates, p.posts, p.activity)).slice(0, 10).map((u) => ({ text: first(u.postText, u.text, u.title, "") })).filter((u) => u.text),
    extras: [
      ...arr(p.licenseAndCertificates).map((c) => `Certification: ${c.title}`),
      ...arr(p.volunteerAndAwards ?? p.volunteering).map((v) => `Volunteering: ${v.title || v.role}`),
      ...arr(p.languages).map((l) => `Language: ${l.title || l.name || l}`),
      ...arr(p.honorsAndAwards).map((h) => `Award: ${h.title}`),
    ].slice(0, 15),
  };
}
