// Synthetic, clearly-fictional source data for local development and tests (no network).
// Never used when APIFY_TOKEN / Graph credentials are configured, and every fixture is labeled.
import { seeded, pick, pickN } from "../util.js";

const JOBS = [
  ["Software Engineer", "Backend systems", ["Go", "PostgreSQL", "Kubernetes", "System design"]],
  ["Product Designer", "Design studio", ["Figma", "User research", "Prototyping", "Design systems"]],
  ["Data Scientist", "Analytics team", ["Python", "Machine learning", "SQL", "Statistics"]],
  ["Founder", "Early-stage startup", ["Fundraising", "Go-to-market", "Hiring", "Product strategy"]],
  ["Resident Doctor", "City hospital", ["Emergency medicine", "Patient care", "Research"]],
  ["Marketing Manager", "Consumer brand", ["Brand strategy", "Content", "Campaigns", "SEO"]],
  ["Architect", "Urban design firm", ["AutoCAD", "Sustainable design", "Urban planning"]],
  ["Teacher", "Public school", ["Curriculum design", "Mentoring", "Public speaking"]],
  ["Investment Analyst", "Venture fund", ["Financial modeling", "Due diligence", "Market research"]],
  ["Journalist", "Newsroom", ["Reporting", "Editing", "Interviewing", "Long-form writing"]],
];
const HOBBIES = {
  trekking: ["Summit at 5am. Legs gone, heart full.", ["trekking", "himalayas", "mountains"], "Kedarkantha base camp"],
  coffee: ["Third pour-over of the day, no regrets.", ["coffee", "pourover", "cafehopping"], "Blue Tokai"],
  running: ["Sub-50 10K. The early mornings paid off.", ["running", "10k", "runnersofinstagram"], "Marine Drive"],
  photography: ["Golden hour does all the work.", ["photography", "35mm", "streetphotography"], "Old Town"],
  cooking: ["Sunday biryani experiment #4. Getting closer.", ["homecooking", "biryani", "foodie"], ""],
  music: ["Open mic night. Played the song I wrote in March.", ["guitar", "openmic", "indiemusic"], "The Piano Man"],
  reading: ["Finished this one in two sittings. Thoughts?", ["bookstagram", "currentlyreading", "fiction"], ""],
  travel: ["Week 2 of backpacking. Night trains are underrated.", ["backpacking", "solotravel", "wanderlust"], "Hampi"],
  football: ["Sunday 5-a-side. We lost, I scored.", ["football", "sundayleague"], "Turf arena"],
  yoga: ["Morning flow before the chaos.", ["yoga", "mindfulness", "morningroutine"], ""],
  gaming: ["Finally finished the DLC. 120 hours well spent.", ["gaming", "pcgaming"], ""],
  pets: ["He has a better social life than me.", ["doglover", "indie_dogs", "adoptdontshop"], ""],
  art: ["Watercolour practice, day 41.", ["watercolor", "sketchbook", "artistsoninstagram"], ""],
  volunteering: ["Beach clean-up crew, 140 kg collected.", ["volunteer", "beachcleanup", "community"], "Versova Beach"],
};
const SCHOOLS = ["State Institute of Technology", "City University", "National Design School", "Institute of Management"];

export function fixtureFor(slug, handle) {
  const rnd = seeded(`${slug}|${handle}`);
  const name = slug.split(/[-_]/).filter((w) => !/^\d+$/.test(w) && w.length > 1).slice(0, 2)
    .map((w) => w[0].toUpperCase() + w.slice(1)).join(" ") || "Alex Doe";
  const [title, company, skills] = pick(rnd, JOBS);
  const hobbies = pickN(rnd, Object.keys(HOBBIES), 3 + Math.floor(rnd() * 2));
  const posts = [];
  for (let i = 0; i < 12; i++) {
    const h = HOBBIES[hobbies[i % hobbies.length]];
    posts.push({ caption: h[0], hashtags: h[1], location: h[2], timestamp: `2026-0${1 + (i % 9)}-1${i % 9}T10:00:00Z`,
      likes: Math.floor(rnd() * 300), type: "Image", imageUrl: "", url: `https://www.instagram.com/p/fixture${i}/` });
  }
  const linkedin = {
    url: `https://www.linkedin.com/in/${slug}/`, name, headline: `${title} at ${company}`, location: pick(rnd, ["Mumbai", "Bengaluru", "Pune", "Delhi", "Hyderabad"]),
    about: `${title} who cares about ${skills[0].toLowerCase()} and ${skills[1].toLowerCase()}. Outside work: ${hobbies.slice(0, 2).join(" and ")}.`,
    photo: "",
    experience: [{ title, company, dates: "2023 – Present", description: `Leading work on ${skills[1].toLowerCase()}.` },
      { title: `Junior ${title}`, company: "Previous company", dates: "2020 – 2023", description: "" }],
    education: [{ school: pick(rnd, SCHOOLS), degree: "Bachelor's degree", dates: "2016 – 2020" }],
    skills, posts: [{ text: `Grateful for a year of learning about ${skills[0]}.` }],
    extras: rnd() > 0.5 ? ["Volunteering: Mentor at a coding club"] : [],
  };
  const instagram = {
    handle, name, bio: `${hobbies.map((h) => h).join(" · ")} | ${linkedin.location}`, externalUrl: "",
    followers: 200 + Math.floor(rnd() * 2000), following: 300 + Math.floor(rnd() * 600), postsCount: 40 + Math.floor(rnd() * 200),
    isPrivate: false, verified: false, category: "", photo: "", posts,
  };
  return { linkedin, instagram };
}

export async function fetchInstagram(handle, slug) { return fixtureFor(slug, handle).instagram; }
export async function fetchLinkedin(slug, url, handle) { return fixtureFor(slug, handle).linkedin; }
