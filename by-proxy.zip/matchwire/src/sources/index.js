import { config } from "../config.js";
import * as apify from "./apify.js";
import * as graph from "./igGraph.js";
import * as fixture from "./fixture.js";

// Exactly two sources per person: their LinkedIn and their Instagram. Nothing else is fetched.
export async function fetchSources({ liSlug, linkedinUrl, igHandle }) {
  const li = config.linkedinProvider === "apify"
    ? apify.fetchLinkedin(liSlug, linkedinUrl)
    : fixture.fetchLinkedin(liSlug, linkedinUrl, igHandle);
  const ig = config.instagramProvider === "apify" ? apify.fetchInstagram(igHandle)
    : config.instagramProvider === "graph" ? graph.fetchInstagram(igHandle)
    : fixture.fetchInstagram(igHandle, liSlug);
  const [linkedin, instagram] = await Promise.all([li, ig]);
  if (instagram.isPrivate) throw new Error(`@${igHandle} is a private Instagram account. Only public profiles can be used.`);
  return {
    linkedin, instagram,
    providers: { linkedin: config.linkedinProvider, instagram: config.instagramProvider },
  };
}
