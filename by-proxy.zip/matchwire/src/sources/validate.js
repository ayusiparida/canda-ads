// Accept only official profile URLs. Returns { liSlug, igHandle, linkedinUrl, instagramUrl } or throws.
const IG_RESERVED = new Set(["p", "reel", "reels", "explore", "stories", "accounts", "direct", "tv", "about", "developer", "legal"]);

export function parseLinkedin(raw) {
  let u;
  try { u = new URL(String(raw).trim()); } catch { throw new Error("The LinkedIn link isn't a valid URL."); }
  if (!/(^|\.)linkedin\.com$/i.test(u.hostname)) throw new Error("The first link must be a linkedin.com profile.");
  const m = u.pathname.match(/^\/in\/([^/?#]+)\/?/i);
  if (!m) throw new Error("Use a LinkedIn profile link like linkedin.com/in/your-name (not a company or post link).");
  const slug = decodeURIComponent(m[1]).toLowerCase();
  return { liSlug: slug, linkedinUrl: `https://www.linkedin.com/in/${encodeURIComponent(slug)}/` };
}

export function parseInstagram(raw) {
  let u;
  try { u = new URL(String(raw).trim()); } catch { throw new Error("The Instagram link isn't a valid URL."); }
  if (!/(^|\.)instagram\.com$/i.test(u.hostname)) throw new Error("The second link must be an instagram.com profile.");
  const seg = u.pathname.split("/").filter(Boolean);
  if (seg.length !== 1 || IG_RESERVED.has(seg[0].toLowerCase()) || !/^[a-z0-9._]{1,30}$/i.test(seg[0]))
    throw new Error("Use an Instagram profile link like instagram.com/handle (not a post or reel).");
  const handle = seg[0].toLowerCase();
  return { igHandle: handle, instagramUrl: `https://www.instagram.com/${handle}/` };
}

export function parseLinks(linkedin, instagram) {
  return { ...parseLinkedin(linkedin), ...parseInstagram(instagram) };
}

// Do these two profiles plausibly belong to the same person? Uses only the two sources.
export function identityCheck(li, ig) {
  const norm = (s) => (s || "").toLowerCase().normalize("NFKD").replace(/[^\p{L}\s]/gu, " ").split(/\s+/).filter((w) => w.length > 1);
  const liTokens = new Set(norm(li.name));
  const igTokens = norm(`${ig.name} ${ig.handle.replace(/[._\d]+/g, " ")}`);
  const overlap = igTokens.filter((t) => liTokens.has(t));
  const handleHasName = [...liTokens].some((t) => t.length > 2 && ig.handle.includes(t));
  const igLinksLi = /linkedin\.com\/in\//i.test(`${ig.externalUrl} ${ig.bio}`);
  const liMentionsIg = new RegExp(`@?${ig.handle.replace(/\./g, "\\.")}\\b`, "i").test(`${li.about} ${li.headline}`);
  const signals = [];
  if (overlap.length) signals.push(`Name match: ${[...new Set(overlap)].join(", ")}`);
  if (handleHasName) signals.push("Instagram handle contains the LinkedIn name");
  if (igLinksLi) signals.push("Instagram bio links to LinkedIn");
  if (liMentionsIg) signals.push("LinkedIn mentions the Instagram handle");
  const score = Math.min(1, overlap.length * 0.35 + (handleHasName ? 0.25 : 0) + (igLinksLi ? 0.4 : 0) + (liMentionsIg ? 0.4 : 0));
  const level = score >= 0.6 ? "strong" : score >= 0.3 ? "likely" : "weak";
  return { score: Number(score.toFixed(2)), level, signals };
}
