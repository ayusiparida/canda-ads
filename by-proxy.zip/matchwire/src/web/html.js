export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const first = (n) => String(n || "").split(" ")[0];

export function avatar(p, size = 40) {
  const initials = String(p?.name || p?.ig_handle || "?").split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  const hue = [...String(p?.id || "x")].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 360, 7);
  // Remote profile photos are often hotlink-blocked, so fall back to initials on error.
  const img = p?.photo_url ? `<img src="${esc(p.photo_url)}" alt="" referrerpolicy="no-referrer" loading="lazy" onerror="this.remove()">` : "";
  return `<span class="av" style="--s:${size}px;--h:${hue}">${esc(initials)}${img}</span>`;
}

export function layout({ title, base = "", body, demo = false, active = "" }) {
  const nav = [["", "Add people"], ["/people", "People"], ["/dates", "Dates"], ["/rankings", "Rankings"]]
    .filter(([href]) => !(demo && href === ""))
    .map(([href, label]) => `<a href="${base}${href || "/"}" class="${active === label ? "on" : ""}">${label}</a>`).join("");
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} · By Proxy</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Young+Serif&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/styles.css">
<link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>💌</text></svg>">
</head><body>
<header class="top"><div class="wrap">
  <a class="brand" href="${base || "/"}${base ? "" : ""}">By Proxy</a>
  <nav>${nav}<a href="/how" class="${active === "How" ? "on" : ""}">How it works</a>${demo ? `<a href="/">Live site</a>` : `<a href="/demo">Demo</a>`}</nav>
</div></header>
${demo ? `<div class="demo-bar"><div class="wrap">You're viewing the finished demo run. It's frozen, so nothing here changes. <a href="/">Add your own links on the live site</a>.</div></div>` : ""}
<main class="wrap">${body}</main>
<footer class="wrap foot">Each person is read from exactly two sources: their LinkedIn and their public Instagram. Everyone in the demo agreed to be included.</footer>
<script src="/app.js" defer></script>
</body></html>`;
}

export const statusLabel = {
  queued: "In line", fetching: "Reading their links", analyzing: "Agent is analyzing",
  ready: "Profile ready", swiping: "Browsing profiles", dating: "On dates", done: "Ranked", error: "Needs attention",
};
