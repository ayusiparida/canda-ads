import { esc, first, avatar, layout, statusLabel } from "./html.js";

const FINAL = ["ready", "done", "error"];

/* ---------------- Home ---------------- */
export function homePage({ people, error, values = {} }) {
  const strip = people.length ? people.map((p) => `<a class="mini" href="/people/${p.id}" title="${esc(p.name || p.ig_handle)}">${avatar(p, 44)}<span>${esc(first(p.name) || "@" + p.ig_handle)}</span><i class="st st-${p.status}">${statusLabel[p.status] || p.status}</i></a>`).join("")
    : `<p class="muted">No one's here yet. Add the first pair of links above.</p>`;
  return layout({ title: "Send your agent on dates", active: "Add people", body: `
<section class="hero">
  <div>
    <h1>Your agent goes on the dates. You get the ranking.</h1>
    <p class="lede">Paste a LinkedIn and a public Instagram. An agent reads both, writes a profile of the person, then goes on real conversation-dates with everyone else's agents and comes back with who fits best.</p>
    <ol class="flow">
      <li><b>Read.</b> Only those two links. Nothing else.</li>
      <li><b>Analyze.</b> Needs, hobbies, interests, values, each tied to a post or role.</li>
      <li><b>Date.</b> Agents pick a venue, talk turn by turn, and think privately.</li>
      <li><b>Rank.</b> Both sides debrief. Fit only counts if it's mutual.</li>
    </ol>
  </div>
  <form class="join" method="post" action="/people">
    <h2>Add a person</h2>
    ${error ? `<p class="err" role="alert">${esc(error)}</p>` : ""}
    <label>LinkedIn profile<input name="linkedin" required placeholder="https://www.linkedin.com/in/…" value="${esc(values.linkedin)}"></label>
    <label>Instagram profile (public)<input name="instagram" required placeholder="https://www.instagram.com/…" value="${esc(values.instagram)}"></label>
    <div class="row2">
      <label>I am <small>(optional)</small><select name="gender"><option value="">Prefer not to say</option><option value="woman">A woman</option><option value="man">A man</option><option value="nonbinary">Non-binary</option></select></label>
      <label>Open to dating<select name="open_to"><option value="anyone">Anyone</option><option value="woman">Women</option><option value="man">Men</option><option value="nonbinary">Non-binary people</option></select></label>
    </div>
    <label class="check"><input type="checkbox" name="consent" required> These are my links, or this person agreed to be added.</label>
    <button type="submit">Send the agent out</button>
    <p class="fine">Takes 1–3 minutes: reading, analysis, then ${5} dates with people already in the pool.</p>
  </form>
</section>
<section><h2>In the pool</h2><div class="strip" data-live-list>${strip}</div></section>` });
}

/* ---------------- People ---------------- */
export function peoplePage({ people, base, demo }) {
  const cards = people.map((p) => {
    const a = p.analysis;
    return `<a class="pcard" href="${base}/people/${p.id}">
      <div class="pc-head">${avatar(p, 52)}<div><b>${esc(p.name || "@" + p.ig_handle)}</b><small>${esc(p.headline)}</small></div></div>
      ${a ? `<p>${esc(a.summary)}</p><div class="chips">${(a.hobbies || []).slice(0, 4).map((h) => `<span class="chip">${esc(h.label)}</span>`).join("")}</div>`
        : `<p class="muted">${statusLabel[p.status] || p.status}${p.error ? `: ${esc(p.error)}` : ""}</p>`}
    </a>`;
  }).join("");
  return layout({ title: "People", base, demo, active: "People", body: `<h1>${people.length} people, ${people.length} agents</h1><div class="grid" data-live-list>${cards || `<p class="muted">No one yet.</p>`}</div>` });
}

const tagLink = (t) => `<a class="ev" href="#src-${esc(t.replace(":", "-"))}">${esc(t)}</a>`;
function itemList(title, items, cls = "") {
  if (!items?.length) return "";
  return `<div class="block ${cls}"><h3>${title}</h3><ul class="items">${items.map((x) =>
    `<li><b>${esc(x.label)}</b><span>${esc(x.why)}</span><em>${(x.evidence || []).map(tagLink).join(" ")}</em></li>`).join("")}</ul></div>`;
}

export function profilePage({ p, ranking, dates, base, demo, people }) {
  const a = p.analysis, li = p.linkedin, ig = p.instagram;
  const byId = Object.fromEntries(people.map((x) => [x.id, x]));
  const idBadge = p.identity ? `<span class="idb id-${p.identity.level}" title="${esc(p.identity.signals.join(" · ") || "No matching signals found")}">${p.identity.level === "strong" ? "Links verified as the same person" : p.identity.level === "likely" ? "Links likely the same person" : "Couldn't confirm these links match"}</span>` : "";
  const head = `<section class="phead">
    ${avatar(p, 88)}
    <div><h1>${esc(p.name || "@" + p.ig_handle)}</h1><p class="muted">${esc(p.headline)}${li?.location ? `, ${esc(li.location)}` : ""}</p>
      <p class="links"><a href="${esc(p.linkedin_url)}" target="_blank" rel="noopener">LinkedIn</a><a href="${esc(p.instagram_url)}" target="_blank" rel="noopener">Instagram @${esc(p.ig_handle)}</a>${idBadge}</p></div>
    <div class="pstatus" ${FINAL.includes(p.status) ? "" : `data-live-person="${p.id}"`}><i class="st st-${p.status}">${statusLabel[p.status]}</i><small>${esc(p.status_detail || "")}</small>
      ${p.status === "error" ? `<p class="err">${esc(p.error)}</p>${demo ? "" : `<form method="post" action="/people/${p.id}/retry"><button>Retry</button></form>`}` : ""}</div>
  </section>`;
  if (!a) return layout({ title: p.name || p.ig_handle, base, demo, body: head + `<section class="working"><div class="pulse"></div><p>The agent is ${p.status === "fetching" ? "reading the two links" : "reading and writing the profile"}. This page updates by itself.</p></section>` });

  const reading = `<section class="reading">
    <h2>How the agent read ${esc(first(p.name))}</h2>
    <ol class="notes">${(a.reading_notes || []).map((n) => `<li>${esc(n).replace(/\((?:LI|IG):[a-z]+\d*\)/gi, (m) => tagLink(m.slice(1, -1)))}</li>`).join("")}</ol>
    <p class="muted small">Read ${ig?.posts?.length || 0} Instagram posts${a.images_read ? ` (looked at ${a.images_read} photos)` : ""} and ${li?.experience?.length || 0} LinkedIn roles. Confidence: <b>${esc(a.confidence)}</b>.</p>
  </section>`;

  const analysis = `<section class="analysis"><h2>The analysis</h2>
    <p class="summary">${esc(a.summary)}</p>
    <div class="cols">
      ${itemList("Needs", a.needs, "need-block")}
      ${itemList("Hobbies", a.hobbies)}
      ${itemList("Interests", a.interests)}
      ${itemList("Values", a.values)}
      ${itemList("Personality", a.personality)}
      <div class="block"><h3>Lifestyle</h3><dl>${Object.entries(a.lifestyle || {}).map(([k, v]) => `<dt>${esc(k.replace(/_/g, " "))}</dt><dd>${esc(v)}</dd>`).join("")}</dl></div>
      <div class="block"><h3>On a date</h3><dl><dt>Talks</dt><dd>${esc(a.communication_style)}</dd><dt>Humor</dt><dd>${esc(a.humor)}</dd><dt>Ideal first date</dt><dd>${esc(a.ideal_first_date)}</dd><dt>Looking for</dt><dd>${esc(a.looking_for)}</dd></dl></div>
      <div class="block"><h3>Green flags</h3><ul class="plain">${(a.green_flags || []).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
        <h3>Could clash with</h3><ul class="plain">${(a.potential_friction || []).map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div>
      <div class="block"><h3>Ask them about</h3><ul class="plain">${(a.conversation_hooks || []).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
        ${a.gaps?.length ? `<h3>What the links don't say</h3><ul class="plain muted">${a.gaps.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}</div>
    </div>
    <details class="persona"><summary>The agent's brief (system prompt it dates with)</summary><pre>${esc(p.persona)}</pre></details>
  </section>`;

  const myDates = dates.filter((d) => d.status !== "failed");
  const dateList = `<section><h2>${esc(first(p.name))}'s dates</h2>${myDates.length ? `<div class="dlist">${myDates.map((d) => dateCard(d, byId, base, p.id)).join("")}</div>` : `<p class="muted">No dates yet.</p>`}</section>`;

  const rankHtml = `<section id="ranking"><h2>Who fits ${esc(first(p.name))} best</h2>${rankingTable(ranking, base)}</section>`;

  const sources = `<section class="sources"><h2>The two sources</h2><div class="cols2">
    <div><h3>LinkedIn</h3>
      <p id="src-LI-headline"><b>${esc(li.headline)}</b></p>${li.about ? `<p id="src-LI-about" class="small">${esc(li.about)}</p>` : ""}
      <ul class="plain small">${li.experience.map((e, i) => `<li id="src-LI-exp${i + 1}"><b>${esc(e.title)}</b>, ${esc(e.company)} <span class="muted">${esc(e.dates)}</span></li>`).join("")}
      ${li.education.map((e, i) => `<li id="src-LI-edu${i + 1}">${esc(e.degree)}, ${esc(e.school)}</li>`).join("")}</ul>
      ${li.skills.length ? `<p id="src-LI-skills" class="small muted">${esc(li.skills.join(", "))}</p>` : ""}
      ${li.posts.map((x, i) => `<p id="src-LI-post${i + 1}" class="small quote">${esc(x.text.slice(0, 280))}</p>`).join("")}
      ${li.extras.map((x, i) => `<p id="src-LI-extra${i + 1}" class="small">${esc(x)}</p>`).join("")}
    </div>
    <div><h3>Instagram @${esc(ig.handle)}</h3><p id="src-IG-bio" class="small">${esc(ig.bio)}</p>
      <ol class="posts">${ig.posts.map((x, i) => `<li id="src-IG-post${i + 1}"><a href="${esc(x.url)}" target="_blank" rel="noopener">post ${i + 1}</a> ${esc(x.caption.slice(0, 160))} ${x.location ? `<span class="muted">· ${esc(x.location)}</span>` : ""}</li>`).join("")}</ol>
    </div></div>
    ${!demo ? `<form method="post" action="/people/${p.id}/delete" class="remove" onsubmit="return confirm('Remove this person, their profile and all their dates?')"><button class="ghost">Remove this person</button></form>` : ""}
  </section>`;
  return layout({ title: p.name, base, demo, active: "People", body: head + reading + analysis + rankHtml + dateList + sources });
}

export function rankingTable(rows, base) {
  if (!rows.length) return `<p class="muted">No ranking yet. Rankings appear once the agents have swiped and dated.</p>`;
  return `<ol class="rank">${rows.map((r) => `<li class="${r.dated ? "dated" : ""}">
    <span class="rk">${r.rank}</span>
    <a href="${base}/people/${r.id}" class="who">${avatar(r, 36)}<span><b>${esc(r.name)}</b><small>${esc(r.headline)}</small></span></a>
    <span class="fit"><b>${r.fit}%</b><small>${r.dated ? (r.mutualSecond ? "both want a 2nd date" : `dated · ${r.myScore}/${r.theirScore}`) : "not dated, profile fit"}</small></span>
    <span class="why">${esc(r.reason)} ${r.dateId ? `<a href="${base}/dates/${r.dateId}">Read the date</a>` : ""}</span>
  </li>`).join("")}</ol>`;
}

/* ---------------- Dates ---------------- */
function dateCard(d, byId, base, focus) {
  const A = byId[d.a_id], B = byId[d.b_id];
  if (!A || !B) return "";
  const sc = Object.fromEntries(d.debriefs.map((x) => [x.person_id, x]));
  return `<a class="dcard st-${d.status}" href="${base}/dates/${d.id}" data-date="${d.id}">
    <span class="pair">${avatar(A, 36)}${avatar(B, 36)}</span>
    <span class="dmeta"><b>${esc(first(A.name))} &amp; ${esc(first(B.name))}</b><small>${esc(d.venue || "Choosing a venue…")}</small></span>
    <span class="dscore">${d.status === "done" ? `${sc[d.a_id]?.score ?? "–"} · ${sc[d.b_id]?.score ?? "–"}${sc[d.a_id]?.second_date && sc[d.b_id]?.second_date ? " ♥" : ""}` : `<i class="st st-${d.status}">${d.status === "live" ? `Live, turn ${d.transcript.length}` : d.status}</i>`}</span>
  </a>`;
}

export function datesPage({ dates, people, base, demo, season }) {
  const byId = Object.fromEntries(people.map((p) => [p.id, p]));
  const live = dates.filter((d) => d.status === "live" || d.status === "debrief");
  const done = dates.filter((d) => d.status === "done");
  return layout({ title: "Dates", base, demo, active: "Dates", body: `
  <h1>${done.length} dates${live.length ? `, ${live.length} happening now` : ""}</h1>
  <p class="muted">Each date: a planner picks a venue both people would enjoy, the two agents talk turn by turn with a private thought before every line, something unscripted happens halfway, and then each agent debriefs its own person.</p>
  ${season ? `<p class="st st-dating">A dating round is running.</p>` : ""}
  ${live.length ? `<h2>Happening now</h2><div class="dlist" data-live-list>${live.map((d) => dateCard(d, byId, base)).join("")}</div>` : ""}
  <h2>Finished</h2><div class="dlist" data-live-list>${done.map((d) => dateCard(d, byId, base)).join("") || `<p class="muted">None yet.</p>`}</div>` });
}

export function turnHtml(t, A, B) {
  if (t.who === "narrator") return `<div class="turn narr">${esc(t.text)}</div>`;
  const side = t.who === A.id ? "l" : "r";
  const who = t.who === A.id ? A : B;
  return `<div class="turn ${side}">${avatar(who, 32)}<div><div class="bubble">${esc(t.say)}</div>${t.thought ? `<div class="thought"><span>${esc(first(who.name))}'s agent thinks</span> ${esc(t.thought)}</div>` : ""}</div></div>`;
}

export function datePage({ d, A, B, base, demo }) {
  const deb = (me, them) => {
    const x = d.debriefs.find((r) => r.person_id === me.id);
    if (!x) return `<div class="debrief pending">${esc(first(me.name))}'s agent hasn't reported back yet.</div>`;
    return `<div class="debrief"><h3>${avatar(me, 28)} ${esc(first(me.name))}'s agent reports back</h3>
      <p class="score"><b>${x.score}</b>/10 · ${x.second_date ? "wants a second date" : "no second date"}</p>
      <p>${esc(x.summary)}</p><dl><dt>Liked</dt><dd>${esc(x.liked)}</dd><dt>Worried</dt><dd>${esc(x.worried)}</dd><dt>The moment</dt><dd>${esc(x.moment)}</dd></dl>
      ${(x.detail.needs_check || []).length ? `<h4>${esc(first(me.name))}'s needs, checked</h4><ul class="needs">${x.detail.needs_check.map((n) => `<li class="m-${esc(n.met)}"><b>${esc(n.met)}</b> ${esc(n.need)}${n.note ? ` <span class="muted">${esc(n.note)}</span>` : ""}</li>`).join("")}</ul>` : ""}</div>`;
  };
  return layout({ title: `${first(A.name)} & ${first(B.name)}`, base, demo, active: "Dates", body: `
  <section class="dhead">
    <a href="${base}/people/${A.id}">${avatar(A, 64)}<b>${esc(A.name)}</b></a>
    <div class="venue"><small>First date</small><h1>${esc(d.venue || "Choosing a venue…")}</h1><p class="muted">${esc(d.venue_why || "")}</p></div>
    <a href="${base}/people/${B.id}">${avatar(B, 64)}<b>${esc(B.name)}</b></a>
  </section>
  <section class="chat" ${d.status === "done" || d.status === "failed" ? "" : `data-live-date="${d.id}"`} data-a='${esc(JSON.stringify({ id: A.id, name: A.name, photo_url: A.photo_url }))}' data-b='${esc(JSON.stringify({ id: B.id, name: B.name, photo_url: B.photo_url }))}'>
    ${d.transcript.map((t) => turnHtml(t, A, B)).join("")}
    ${d.status === "live" ? `<div class="typing" aria-live="polite">The agents are talking…</div>` : ""}
    ${d.status === "failed" ? `<p class="err">This date was interrupted.</p>` : ""}
  </section>
  <section class="debriefs">${deb(A, B)}${deb(B, A)}</section>` });
}

/* ---------------- Rankings ---------------- */
export function rankingsPage({ people, rankings, couples, base, demo }) {
  const byId = Object.fromEntries(people.map((p) => [p.id, p]));
  return layout({ title: "Rankings", base, demo, active: "Rankings", body: `
  <h1>Rankings</h1>
  <p class="muted">For every person, everyone else ranked by fit. A high score needs both agents to want it: after a date, fit uses the geometric mean of the two private debrief scores, plus a bonus if both want a second date.</p>
  ${couples.length ? `<h2>Strongest mutual matches</h2><ol class="couples">${couples.map((c) => `<li><a href="${base}/dates/${c.dateId}">${avatar(byId[c.a], 40)}${avatar(byId[c.b], 40)}<span><b>${esc(first(byId[c.a]?.name))} &amp; ${esc(first(byId[c.b]?.name))}</b><small>${c.fit}% fit${c.mutualSecond ? " · both want a 2nd date" : ""}</small></span></a></li>`).join("")}</ol>` : ""}
  <h2>Everyone's top 5</h2>
  <div class="rgrid">${people.filter((p) => p.analysis).map((p) => `<div class="rcard"><a href="${base}/people/${p.id}#ranking" class="who">${avatar(p, 40)}<b>${esc(p.name)}</b></a>
    <ol>${(rankings[p.id] || []).slice(0, 5).map((r) => `<li><a href="${base}/people/${r.id}">${esc(r.name)}</a><span>${r.fit}%</span>${r.dated ? "" : `<small>undated</small>`}</li>`).join("") || `<li class="muted">Not ranked yet</li>`}</ol></div>`).join("")}</div>` });
}

/* ---------------- How it works ---------------- */
export function howPage() {
  return layout({ title: "How it works", active: "How", body: `<article class="how">
  <h1>How By Proxy works</h1>
  <p class="lede">One agent per person. It only knows what's on that person's LinkedIn and public Instagram, and it dates on their behalf.</p>
  <h2>1. Reading the two links</h2>
  <p>Links are validated as real profile URLs (linkedin.com/in/…, instagram.com/handle). Profiles are fetched server-side through a scraping API; private Instagram accounts are rejected. The site then checks whether the two links plausibly belong to the same person (name match, handle, cross-links) and shows that as a badge on the profile.</p>
  <h2>2. Analysis</h2>
  <p>Both profiles become a numbered reading pack: every LinkedIn role, education entry, skill list, and Instagram post gets a tag like LI:exp2 or IG:post7. The analysis model reads the pack and up to six post photos, then writes needs, hobbies, interests, values, personality, lifestyle, conversation hooks, green flags and possible friction. Every claim must cite tags, and the profile page links each tag back to the exact post or role. It's told not to infer orientation, religion, ethnicity, health, politics or money.</p>
  <h2>3. The agent</h2>
  <p>The analysis becomes the agent's brief: it speaks as the person, wants what they need, and may only share facts from the sources. You can read the brief on every profile page.</p>
  <h2>4. Dating</h2>
  <p><b>Swipe:</b> each agent reads every compatible profile card and scores fit from its own person's needs, then asks out its top four. <b>Pairing:</b> mutual asks first, then asks, then a matchmaker fills gaps so everyone gets at least five dates. <b>The date:</b> a planner picks a venue from what both enjoy and writes one unscripted moment. The two agents alternate for ten turns; before every line each writes a private thought the other can't see. <b>Debrief:</b> each agent reports to its own person privately: score, second date or not, the telling moment, and a check of each of its person's needs.</p>
  <h2>5. Ranking</h2>
  <p>Dated pairs: 15% swipe scores, 65% the geometric mean of both debrief scores, 20% second-date agreement. Undated pairs rank on swipe scores at a discount. One-sided chemistry can't reach the top.</p>
  <h2>Trying it</h2>
  <p>Paste your own links on the home page. Your agent reads you, swipes the whole pool, goes on five dates, and your ranking appears on your profile page. The demo run is frozen at <a href="/demo">/demo</a>.</p>
  </article>` });
}

export function adminPage({ token, msg, counts, running }) {
  return layout({ title: "Admin", body: `<h1>Admin</h1>${msg ? `<p class="note">${esc(msg)}</p>` : ""}
  <p class="muted">${counts.people} people (${counts.demo} demo), ${counts.dates} dates. ${running ? "A season is running." : ""}</p>
  <form method="post" action="/admin/bulk?token=${esc(token)}" class="join"><h2>Bulk add demo people</h2>
    <p class="fine">One person per line: linkedin_url instagram_url [gender] [open_to]</p>
    <textarea name="lines" rows="10" placeholder="https://www.linkedin.com/in/… https://www.instagram.com/… woman man"></textarea>
    <button>Add and analyze</button></form>
  <form method="post" action="/admin/season?token=${esc(token)}" class="join"><h2>Run a dating season</h2>
    <label class="check"><input type="checkbox" name="demo" checked> Demo people only</label><button>Start dating</button></form>` });
}
