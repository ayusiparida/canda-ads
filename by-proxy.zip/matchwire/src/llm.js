import { config } from "./config.js";

let inFlight = 0;
const waiters = [];
async function slot() {
  if (inFlight < config.llmConcurrency) { inFlight++; return; }
  await new Promise((r) => waiters.push(r));
  inFlight++;
}
function release() { inFlight--; waiters.shift()?.(); }

export const stats = { calls: 0, inputTokens: 0, outputTokens: 0 };

async function anthropic({ model, system, messages, maxTokens, temperature }) {
  for (let attempt = 0; attempt < 5; attempt++) {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": config.anthropicKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model, system, messages, max_tokens: maxTokens, temperature }),
    });
    if (res.ok) {
      const data = await res.json();
      stats.calls++; stats.inputTokens += data.usage?.input_tokens || 0; stats.outputTokens += data.usage?.output_tokens || 0;
      return data.content.filter((b) => b.type === "text").map((b) => b.text).join("");
    }
    const body = await res.text();
    if ([429, 500, 502, 503, 529].includes(res.status)) { await new Promise((r) => setTimeout(r, 1500 * 2 ** attempt)); continue; }
    const err = new Error(`Anthropic API ${res.status}: ${body.slice(0, 300)}`); err.status = res.status; err.body = body; throw err;
  }
  throw new Error("Anthropic API kept returning overload errors.");
}

/** Text completion. `mock` is a function returning what a model would say, used when LLM_PROVIDER=mock. */
export async function complete({ model, system, messages, maxTokens = 800, temperature = 0.8, mock }) {
  if (config.llmProvider === "mock") {
    stats.calls++;
    await new Promise((r) => setTimeout(r, 15 + Math.random() * 40));
    return typeof mock === "function" ? mock() : String(mock ?? "");
  }
  await slot();
  try { return await anthropic({ model, system, messages, maxTokens, temperature }); }
  finally { release(); }
}

export function parseJson(text) {
  const cleaned = text.replace(/```json|```/g, "").trim();
  const start = cleaned.search(/[[{]/);
  const end = Math.max(cleaned.lastIndexOf("}"), cleaned.lastIndexOf("]"));
  return JSON.parse(cleaned.slice(start, end + 1));
}

/** JSON completion with one repair retry. */
export async function completeJson(opts) {
  const text = await complete({ ...opts, temperature: opts.temperature ?? 0.4, mock: opts.mock && (() => JSON.stringify(opts.mock())) });
  try { return parseJson(text); }
  catch {
    const fixed = await complete({
      ...opts, temperature: 0,
      messages: [...opts.messages, { role: "assistant", content: text }, { role: "user", content: "That was not valid JSON. Reply again with only the JSON, no prose, no code fences." }],
      mock: opts.mock && (() => JSON.stringify(opts.mock())),
    });
    return parseJson(fixed);
  }
}
