import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";

fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
export const db = new Database(config.dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS people (
  id TEXT PRIMARY KEY,
  linkedin_url TEXT NOT NULL,
  instagram_url TEXT NOT NULL,
  li_slug TEXT NOT NULL,
  ig_handle TEXT NOT NULL,
  name TEXT,
  photo_url TEXT,
  gender TEXT DEFAULT '',
  open_to TEXT DEFAULT 'anyone',
  is_demo INTEGER DEFAULT 0,
  status TEXT DEFAULT 'queued',
  status_detail TEXT DEFAULT '',
  error TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  UNIQUE (li_slug, ig_handle)
);
CREATE TABLE IF NOT EXISTS sources (
  person_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  provider TEXT NOT NULL,
  data_json TEXT NOT NULL,
  fetched_at TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (person_id, kind)
);
CREATE TABLE IF NOT EXISTS profiles (
  person_id TEXT PRIMARY KEY REFERENCES people(id) ON DELETE CASCADE,
  analysis_json TEXT NOT NULL,
  persona TEXT NOT NULL,
  identity_json TEXT NOT NULL,
  model TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS swipes (
  from_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  to_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  score REAL NOT NULL,
  reason TEXT,
  ask INTEGER DEFAULT 0,
  PRIMARY KEY (from_id, to_id)
);
CREATE TABLE IF NOT EXISTS dates (
  id TEXT PRIMARY KEY,
  a_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  b_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  venue TEXT, venue_why TEXT, twist TEXT,
  status TEXT DEFAULT 'planned',
  transcript_json TEXT DEFAULT '[]',
  created_at TEXT DEFAULT (datetime('now')),
  finished_at TEXT
);
CREATE TABLE IF NOT EXISTS debriefs (
  date_id TEXT NOT NULL REFERENCES dates(id) ON DELETE CASCADE,
  person_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  about_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  score REAL NOT NULL,
  second_date INTEGER NOT NULL,
  liked TEXT, worried TEXT, summary TEXT, moment TEXT, detail_json TEXT DEFAULT '{}',
  PRIMARY KEY (date_id, person_id)
);
`);

// Anything left mid-flight by a crash or redeploy is marked so it can be retried.
db.exec(`
UPDATE people SET status='error', error='Interrupted by a server restart. Press Retry.'
  WHERE status IN ('fetching','analyzing');
UPDATE people SET status='ready' WHERE status IN ('swiping','dating');
UPDATE dates SET status='failed' WHERE status IN ('planned','live','debrief');
`);

export const j = (s, fallback = null) => { try { return JSON.parse(s); } catch { return fallback; } };
