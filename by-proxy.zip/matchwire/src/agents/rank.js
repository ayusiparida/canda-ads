import { db } from "../db.js";
import { getPerson, compatible } from "../store.js";

/**
 * Rank everyone in scope for one person.
 * Dated pairs:   fit = 0.15·mean(swipes) + 0.65·√(my debrief × their debrief) + 0.20·second-date agreement
 * Undated pairs: fit = 0.6·mean(swipes)   (capped below dated pairs that went well)
 * The geometric mean means one-sided chemistry can't produce a top match.
 */
export function rankFor(personId, scopeIds) {
  const me = getPerson(personId);
  if (!me) return [];
  const scope = new Set(scopeIds);
  const swipe = (f, t) => db.prepare("SELECT score, reason FROM swipes WHERE from_id=? AND to_id=?").get(f, t);
  const dates = db.prepare("SELECT id FROM dates WHERE status='done' AND ((a_id=? AND b_id=?) OR (a_id=? AND b_id=?)) ORDER BY finished_at DESC");
  const deb = db.prepare("SELECT * FROM debriefs WHERE date_id=? AND person_id=?");
  const rows = [];
  for (const oid of scope) {
    if (oid === personId) continue;
    const other = getPerson(oid);
    if (!other?.analysis || !compatible(me, other)) continue;
    const s1 = swipe(personId, oid), s2 = swipe(oid, personId);
    const sw = [s1?.score, s2?.score].filter((x) => x != null);
    const swipeMean = sw.length ? sw.reduce((a, b) => a + b, 0) / sw.length : 0;
    const d = dates.get(personId, oid, oid, personId);
    let fit, reason, dated = false, mine = null, theirs = null, dateId = null;
    if (d) {
      mine = deb.get(d.id, personId); theirs = deb.get(d.id, oid);
    }
    if (mine && theirs) {
      dated = true; dateId = d.id;
      const both = mine.second_date && theirs.second_date ? 10 : mine.second_date || theirs.second_date ? 4 : 0;
      fit = 0.15 * swipeMean + 0.65 * Math.sqrt(mine.score * theirs.score) + 0.2 * both;
      reason = mine.summary;
    } else {
      fit = 0.6 * swipeMean;
      reason = s1?.reason || s2?.reason || "";
    }
    rows.push({ id: oid, name: other.name, headline: other.headline, photo: other.photo_url, fit: Math.round(fit * 10),
      dated, dateId, reason, myScore: mine?.score ?? null, theirScore: theirs?.score ?? null,
      mutualSecond: !!(mine?.second_date && theirs?.second_date), swipeMine: s1?.score ?? null, swipeTheirs: s2?.score ?? null });
  }
  return rows.sort((a, b) => b.fit - a.fit).map((r, i) => ({ ...r, rank: i + 1 }));
}

/** Best mutual pairs across the pool: both people rank each other highly. */
export function topCouples(scopeIds, n = 10) {
  const seen = new Set(); const out = [];
  for (const id of scopeIds) for (const r of rankFor(id, scopeIds)) {
    if (!r.dated) continue;
    const key = [id, r.id].sort().join("|");
    if (seen.has(key)) continue; seen.add(key);
    out.push({ a: id, b: r.id, fit: r.fit, dateId: r.dateId, mutualSecond: r.mutualSecond });
  }
  return out.sort((x, y) => y.fit - x.fit).slice(0, n);
}
