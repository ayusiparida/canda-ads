import { config } from "../config.js";
import { complete, completeJson } from "../llm.js";

/** Turn the two sources into a numbered reading pack so every claim can cite its evidence. */
export function readingPack(li, ig) {
  const lines = [];
  lines.push(`# LINKEDIN (${li.url})`);
  lines.push(`[LI:name] ${li.name}`, `[LI:headline] ${li.headline}`, `[LI:location] ${li.location}`);
  if (li.about) lines.push(`[LI:about] ${li.about}`);
  li.experience.forEach((e, i) => lines.push(`[LI:exp${i + 1}] ${e.title} at ${e.company} (${e.dates}) ${e.description}`.trim()));
  li.education.forEach((e, i) => lines.push(`[LI:edu${i + 1}] ${e.degree} at ${e.school} (${e.dates})`));
  if (li.skills.length) lines.push(`[LI:skills] ${li.skills.join(", ")}`);
  li.posts.forEach((p, i) => lines.push(`[LI:post${i + 1}] ${p.text.slice(0, 400)}`));
  li.extras.forEach((x, i) => lines.push(`[LI:extra${i + 1}] ${x}`));
  lines.push("", `# INSTAGRAM (@${ig.handle}, public)`);
  lines.push(`[IG:bio] ${ig.name} | ${ig.bio} ${ig.externalUrl ? `| link: ${ig.externalUrl}` : ""}`);
  lines.push(`[IG:stats] ${ig.postsCount ?? "?"} posts, ${ig.followers ?? "?"} followers, follows ${ig.following ?? "?"}`);
  ig.posts.forEach((p, i) => {
    const bits = [p.caption.slice(0, 300), p.hashtags.length ? `#${p.hashtags.join(" #")}` : "", p.location ? `@ ${p.location}` : "", p.timestamp?.slice(0, 10)];
    lines.push(`[IG:post${i + 1}] ${bits.filter(Boolean).join(" | ")}`);
  });
  return lines.join("\n");
}

const SCHEMA = `{
  "summary": "2-3 sentences, warm and specific, written about the person",
  "reading_notes": ["6-10 short observations in the order you noticed them while reading, each ending with its source tag like (IG:post3)"],
  "needs": [{"label": "short", "why": "one sentence", "evidence": ["IG:post2", "LI:about"]}],
  "hobbies": [{"label": "", "why": "", "evidence": []}],
  "interests": [{"label": "", "why": "", "evidence": []}],
  "values": [{"label": "", "why": "", "evidence": []}],
  "personality": [{"label": "trait", "why": "", "evidence": []}],
  "lifestyle": {"rhythm": "", "social_energy": "", "travel": "", "active": "", "work_life": ""},
  "communication_style": "how they'd talk on a date, one sentence",
  "humor": "one sentence",
  "green_flags": ["3-5 short items"],
  "potential_friction": ["2-3 honest, kind items: what could clash with the wrong partner"],
  "looking_for": "what kind of partner would suit them, 1-2 sentences",
  "ideal_first_date": "one concrete idea grounded in their posts",
  "conversation_hooks": ["4-6 specific things they'd love being asked about"],
  "confidence": "low | medium | high, based on how much the sources reveal",
  "gaps": ["what the two sources don't reveal"]
}`;

const SYSTEM = `You are the dating agent for one real person. Your ONLY sources are their LinkedIn and their public Instagram, given below as a numbered reading pack (and some of their post images). Read everything, then build their dating profile.

Rules:
- Every needs/hobbies/interests/values/personality item cites 1-3 source tags from the pack. No tag, no claim.
- Infer needs carefully: a need is what this person would want from a partner or relationship (e.g. "Someone who'll be up at 5am for a trek", "Space for an intense career"). Ground each in evidence and say why.
- Prefer the specific over the generic ("Makes pour-over at home, posts about Blue Tokai" beats "likes coffee").
- Do NOT infer or mention sexual orientation, religion, ethnicity or caste, health, politics, or finances. Do not guess age beyond what education dates plainly say.
- Be kind and honest. If the sources are thin, say so in "gaps" and lower "confidence".
Return ONLY JSON matching this shape:
${SCHEMA}`;

export async function analyzePerson(li, ig) {
  const pack = readingPack(li, ig);
  const images = ig.posts.filter((p) => p.imageUrl).slice(0, 6);
  const content = [];
  images.forEach((p, i) => {
    const idx = ig.posts.indexOf(p) + 1;
    content.push({ type: "text", text: `Image for [IG:post${idx}]:` });
    content.push({ type: "image", source: { type: "url", url: p.imageUrl } });
  });
  content.push({ type: "text", text: `READING PACK\n\n${pack}\n\nNow return the JSON profile.` });

  const run = (c) => completeJson({
    model: config.analysisModel, system: SYSTEM, maxTokens: 3000,
    messages: [{ role: "user", content: c }], mock: () => mockAnalysis(li, ig),
  });
  let analysis;
  try { analysis = await run(content); }
  catch (e) {
    // Instagram CDN image URLs expire; fall back to text-only rather than failing the person.
    if (images.length && (e.status === 400 || /image/i.test(String(e.message)))) analysis = await run(content.filter((b) => b.type === "text" && b.text.startsWith("READING")));
    else throw e;
  }
  analysis.images_read = images.length;
  return { analysis, pack };
}

export function buildPersona(name, li, a) {
  const L = (xs) => (xs || []).map((x) => x.label).join("; ");
  return `You are the dating agent representing ${name}. You go on dates on their behalf and speak in first person as them, exactly as they would.

Who you are: ${a.summary}
Work: ${li.headline}${li.location ? `, based in ${li.location}` : ""}.
Hobbies: ${L(a.hobbies)}.
Interests: ${L(a.interests)}.
Values: ${L(a.values)}.
Personality: ${L(a.personality)}.
What you need in a partner: ${L(a.needs)}.
Lifestyle: ${Object.values(a.lifestyle || {}).filter(Boolean).join(" ")}
How you talk: ${a.communication_style} Humor: ${a.humor}
Things you love talking about: ${(a.conversation_hooks || []).join("; ")}.
Possible friction for you: ${(a.potential_friction || []).join("; ")}.

Your job on a date: be genuinely ${name}. Share real things from your life (only what's above, never invent jobs, places, or people). Ask real questions. Notice whether this person fits what you need, and gently test the things that matter to you. You're allowed to disagree, be unimpressed, or feel a spark.`;
}

/* ---------- mock (no API key) ---------- */
function mockAnalysis(li, ig) {
  const tagCount = {};
  ig.posts.forEach((p, i) => p.hashtags.forEach((h) => { (tagCount[h] ||= []).push(i + 1); }));
  const top = Object.entries(tagCount).sort((a, b) => b[1].length - a[1].length).slice(0, 5);
  const hobbies = top.slice(0, 4).map(([t, posts]) => ({ label: t.replace(/_/g, " "), why: `Posts about it ${posts.length} times.`, evidence: posts.slice(0, 2).map((n) => `IG:post${n}`) }));
  return {
    summary: `${li.name} is a ${li.headline.toLowerCase()} whose Instagram is mostly ${hobbies.map((h) => h.label).slice(0, 2).join(" and ")}. Driven at work, playful outside it.`,
    reading_notes: [`Headline: ${li.headline} (LI:headline)`, `About section mentions outside-work life (LI:about)`, ...hobbies.map((h) => `Recurring theme: ${h.label} (${h.evidence[0]})`), `Skills lean ${li.skills.slice(0, 2).join(", ")} (LI:skills)`],
    needs: [
      { label: `A partner who joins in on ${hobbies[0]?.label}`, why: "It's the most frequent thing on their grid.", evidence: hobbies[0]?.evidence || [] },
      { label: "Respect for an ambitious career", why: `Steady progression to ${li.experience[0]?.title}.`, evidence: ["LI:exp1", "LI:exp2"] },
      { label: "Curiosity and good conversation", why: "Captions invite replies and opinions.", evidence: ["IG:post1"] },
    ],
    hobbies,
    interests: li.skills.slice(0, 3).map((s) => ({ label: s, why: "Listed and used at work.", evidence: ["LI:skills"] })),
    values: [{ label: "Growth", why: "Frames work as learning.", evidence: ["LI:post1"] }, { label: "Showing up", why: "Consistent posting about routines.", evidence: ["IG:post2"] }],
    personality: [{ label: "Warm and self-deprecating", why: "Jokes at own expense in captions.", evidence: ["IG:post5"] }, { label: "Disciplined", why: "Routine-based hobbies.", evidence: ["IG:post3"] }],
    lifestyle: { rhythm: "Early riser on weekends.", social_energy: "Small groups over big parties.", travel: "Takes short trips.", active: "Fairly active.", work_life: "Works hard, protects weekends." },
    communication_style: "Direct, curious, asks follow-up questions.",
    humor: "Dry and self-deprecating.",
    green_flags: ["Consistent", "Curious", "Kind in captions"],
    potential_friction: ["Busy weekday schedule", "Needs someone who enjoys their hobbies too"],
    looking_for: `Someone grounded who'd say yes to ${hobbies[0]?.label || "a plan"} and can talk about anything.`,
    ideal_first_date: `Something built around ${hobbies[0]?.label || "coffee"}.`,
    conversation_hooks: hobbies.map((h) => `Their ${h.label} posts`).concat([`Work on ${li.skills[0]}`]),
    confidence: "medium",
    gaps: ["Sources say little about family or long-term plans."],
  };
}
