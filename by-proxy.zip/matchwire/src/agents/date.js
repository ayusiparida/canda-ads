import { config } from "../config.js";
import { complete, completeJson } from "../llm.js";
import { card, overlap } from "./swipe.js";
import { seeded, pick, clamp } from "../util.js";

const first = (n) => n.split(" ")[0];

/** A neutral "date planner" picks a venue both people would actually enjoy, plus one unscripted moment. */
export async function planDate(a, b) {
  const shared = overlap(a, b);
  return completeJson({
    model: config.dateModel, maxTokens: 500, temperature: 0.9,
    system: "You plan first dates between two people's dating agents. Pick a specific, realistic venue or activity drawn from what BOTH would enjoy (use their profiles). Then write one small unscripted moment that will happen mid-date and reveal character (e.g. rain starts, the place is out of their dish, a street musician asks for a song request). Keep it light and safe.",
    messages: [{ role: "user", content: `Person A:\n${card(a)}\n\nPerson B:\n${card(b)}\n\nReturn ONLY JSON: {"venue":"specific place/activity","why":"one sentence naming what each of them gets from it","twist":"the unscripted moment, one sentence, present tense"}` }],
    mock: () => mockPlan(a, b, shared),
  });
}

function rules(me, them, plan) {
  return `${me.persona}

DATE: You're on a first date with ${them.name} (${them.headline}). Venue: ${plan.venue}.
What you know about them before the date (from their profile card): ${them.analysis.summary}

How to reply, every turn, in exactly this format:
THOUGHT: (private, one sentence: what you're noticing about fit with YOUR needs; ${them.name} never sees this)
SAY: (what you say out loud, 1-3 natural sentences, in your own voice; react to what they just said, share something real, ask something)

Lines in [brackets] are things happening around you, react to them naturally. Don't summarize the date or narrate actions. Never invent facts about your life that aren't in your profile.`;
}

function parseTurn(text) {
  const t = text.match(/THOUGHT:\s*([\s\S]*?)(?:\n\s*SAY:|$)/i)?.[1]?.trim() || "";
  let s = text.match(/SAY:\s*([\s\S]*)$/i)?.[1]?.trim() || text.replace(/THOUGHT:[^\n]*\n?/i, "").trim();
  s = s.replace(/^["“]|["”]$/g, "");
  return { thought: t, say: s };
}

/** Rebuild the transcript from one agent's point of view as a chat (their lines = assistant). */
function viewFor(me, them, transcript, plan) {
  const msgs = [];
  const push = (role, text) => {
    const last = msgs[msgs.length - 1];
    if (last && last.role === role) last.content += `\n${text}`; else msgs.push({ role, content: text });
  };
  push("user", `[You arrive at ${plan.venue}. ${them.name} is here.]`);
  for (const t of transcript) {
    if (t.who === "narrator") push("user", `[${t.text}]`);
    else if (t.who === me.id) push("assistant", `THOUGHT: ${t.thought}\nSAY: ${t.say}`);
    else push("user", `${first(them.name)}: ${t.say}`);
  }
  if (msgs[msgs.length - 1].role === "assistant") push("user", "[Your turn.]");
  return msgs;
}

export async function runDate(a, b, { onEvent = () => {} } = {}) {
  const plan = await planDate(a, b);
  onEvent({ kind: "plan", plan });
  const transcript = [];
  const turns = config.turnsPerDate;
  const twistAt = Math.floor(turns / 2);
  let [me, them] = seeded(a.id + b.id)() < 0.5 ? [a, b] : [b, a];
  for (let i = 0; i < turns; i++) {
    if (i === twistAt && plan.twist) {
      const ev = { who: "narrator", text: plan.twist };
      transcript.push(ev); onEvent({ kind: "turn", turn: ev });
    }
    const wrapUp = i >= turns - 2 ? "\n[The date is winding down. Respond naturally; it's fine to say what you'd want next, or not.]" : "";
    const messages = viewFor(me, them, transcript, plan);
    if (wrapUp) messages[messages.length - 1].content += wrapUp;
    const text = await complete({
      model: config.dateModel, maxTokens: 300, temperature: 0.9, system: rules(me, them, plan), messages,
      mock: () => mockTurn(me, them, transcript, plan, i, turns),
    });
    const turn = { who: me.id, ...parseTurn(text) };
    transcript.push(turn); onEvent({ kind: "turn", turn });
    [me, them] = [them, me];
  }
  return { plan, transcript };
}

/** Each agent privately reports back to its person. Asymmetric on purpose. */
export async function debrief(me, them, plan, transcript) {
  const lines = transcript.map((t) => t.who === "narrator" ? `[${t.text}]`
    : t.who === me.id ? `ME: ${t.say}\n   (my thought: ${t.thought})` : `${first(them.name).toUpperCase()}: ${t.say}`).join("\n");
  const needs = (me.analysis.needs || []).map((n) => n.label);
  const out = await completeJson({
    model: config.dateModel, maxTokens: 900, temperature: 0.5,
    system: `${me.persona}\n\nThe date is over. Report back honestly and privately to your person. Judge only by THEIR needs and values. Don't be polite on their behalf: a pleasant date with no real fit is a 4-5.`,
    messages: [{ role: "user", content: `Date with ${them.name} at ${plan.venue}.\n\nTranscript:\n${lines}\n\nYour person's needs: ${JSON.stringify(needs)}\n\nReturn ONLY JSON:\n{"score": 0-10 number, "second_date": true/false, "liked": "one sentence", "worried": "one sentence", "moment": "the single line or moment that told you the most, quoted or described", "summary": "two sentences to your person: would they click and why", "needs_check": [{"need": "...", "met": "yes|partly|no|unknown", "note": "short"}]}` }],
    mock: () => mockDebrief(me, them, plan, transcript),
  });
  return {
    score: clamp(Number(out.score) || 0, 0, 10), second_date: !!out.second_date,
    liked: String(out.liked || ""), worried: String(out.worried || ""), moment: String(out.moment || ""),
    summary: String(out.summary || ""), needs_check: Array.isArray(out.needs_check) ? out.needs_check.slice(0, 6) : [],
  };
}

/* ---------- mock (no API key) ---------- */
const VENUES = { trekking: "a sunrise trail walk", coffee: "a third-wave coffee tasting flight", running: "a 5K fun run followed by breakfast", photography: "a golden-hour photo walk through the old town", cooking: "a two-person pasta-making class", music: "an open mic night at a small bar", reading: "a used-book store treasure hunt then chai", travel: "a day trip on the slow train", football: "a five-a-side game and post-match food", yoga: "a rooftop sunset yoga class", gaming: "a retro arcade bar", pets: "a dog-shelter volunteering afternoon", art: "a pottery-painting studio", volunteering: "a beach clean-up and fresh coconut water" };
function mockPlan(a, b, shared) {
  const key = Object.keys(VENUES).find((k) => shared.some((s) => s.includes(k))) || pick(seeded(a.id + b.id), Object.keys(VENUES));
  return { venue: VENUES[key], why: `${first(a.name)} and ${first(b.name)} both light up around ${key}.`,
    twist: pick(seeded(b.id + a.id), ["It starts raining hard and the only shelter is a tiny awning.", "The place has run out of the one thing they both wanted.", "A street musician asks them to pick the next song.", "A stranger asks them to settle a debate about pineapple on pizza."]) };
}
function mockTurn(me, them, transcript, plan, i, turns) {
  const r = seeded(me.id + i);
  const myHook = pick(r, me.analysis.conversation_hooks || ["work"]);
  const theirHobby = pick(r, (them.analysis.hobbies || [{ label: "weekends" }]).map((h) => h.label));
  const shared = overlap(me, them);
  const last = [...transcript].reverse().find((t) => t.who !== me.id);
  if (i === 0) return `THOUGHT: First impressions. I want to know if ${first(them.name)} would actually fit my routines.\nSAY: Hey! I hoped this place would feel like both of us. I'm ${first(me.name)}. Okay, honest question to start: how much of your Instagram is ${theirHobby}, really?`;
  if (last?.who === "narrator") return `THOUGHT: How someone handles a curveball says a lot.\nSAY: Well, that's one way to make a date memorable. Honestly I don't mind. Bad plans make the best stories. What's your worst-plan-turned-best-story?`;
  if (i >= turns - 2) return `THOUGHT: ${shared.length ? `We actually overlap on ${shared[0]}. That matters to me.` : "Pleasant, but I'm not sure we want the same things."}\nSAY: ${shared.length ? `I'd do this again. Next time ${shared[0]}, your pick of place?` : `This was genuinely nice. I'm glad I met you, ${first(them.name)}.`}`;
  return `THOUGHT: ${shared.length ? `They get ${shared[r() * shared.length | 0]}. Good sign.` : `Different worlds. Testing if that's interesting or just different.`}\nSAY: ${last ? "Ha, fair. " : ""}For me it's ${myHook.toLowerCase().replace(/^their /, "my ")}. That's where I'm happiest. What's the thing you'd drop everything for?`;
}
function mockDebrief(me, them, plan, transcript) {
  const shared = overlap(me, them);
  const r = seeded(me.id + them.id + "d")();
  const score = clamp(2.5 + shared.length * 0.9 + r * 3.5, 0, 10);
  return { score: Number(score.toFixed(1)), second_date: score >= 6.5,
    liked: shared.length ? `${first(them.name)} genuinely shares ${shared[0]}.` : `${first(them.name)} was easy to talk to.`,
    worried: score < 6 ? "Our weekends would look completely different." : "Busy schedules on both sides.",
    moment: transcript.find((t) => t.who === them.id)?.say?.slice(0, 120) || "",
    summary: score >= 6.5 ? `I'd go again. We clicked on ${shared[0] || "humor"} and they asked good questions.` : "Nice person, but I didn't see the fit with what you need.",
    needs_check: (me.analysis.needs || []).slice(0, 3).map((n, i) => ({ need: n.label, met: ["yes", "partly", "unknown"][(i + Math.floor(r * 3)) % 3], note: "" })) };
}
