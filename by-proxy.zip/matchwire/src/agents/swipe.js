import { config } from "../config.js";
import { completeJson } from "../llm.js";
import { seeded, clamp } from "../util.js";

export function card(p) {
  const a = p.analysis;
  const L = (xs) => (xs || []).map((x) => x.label).join("; ");
  return `id=${p.id} | ${p.name} | ${p.headline}
  About: ${a.summary}
  Hobbies: ${L(a.hobbies)} | Interests: ${L(a.interests)} | Values: ${L(a.values)}
  Needs: ${L(a.needs)} | Looking for: ${a.looking_for}`;
}

/** One agent reads every candidate card and decides who to ask out. */
export async function swipe(me, candidates, asks = config.asksPerAgent) {
  if (!candidates.length) return [];
  const system = `${me.persona}\n\nYou're browsing profiles of people your person could date. Judge each one strictly from YOUR person's needs and values, not general attractiveness. Be selective: most people are a 3-6.`;
  const user = `Candidates:\n\n${candidates.map(card).join("\n\n")}\n\nScore every candidate 0-10 for fit with you, give a one-sentence reason in first person that names a specific overlap or clash, and set "ask": true for the ${asks} you'd most want to go on a date with.\nReturn ONLY JSON: [{"id":"...","score":7.5,"reason":"...","ask":true}]`;
  const out = await completeJson({
    model: config.dateModel, system, maxTokens: 2500,
    messages: [{ role: "user", content: user }],
    mock: () => mockSwipe(me, candidates, asks),
  });
  const valid = new Set(candidates.map((c) => c.id));
  const rows = (Array.isArray(out) ? out : out.candidates || []).filter((r) => valid.has(r.id))
    .map((r) => ({ id: r.id, score: clamp(Number(r.score) || 0, 0, 10), reason: String(r.reason || ""), ask: !!r.ask }));
  // Guarantee exactly `asks` asks, highest scores first, whatever the model did.
  rows.sort((a, b) => b.score - a.score);
  rows.forEach((r, i) => (r.ask = i < asks));
  return rows;
}

export function overlap(a, b) {
  const set = (p) => new Set([...(p.analysis.hobbies || []), ...(p.analysis.interests || []), ...(p.analysis.values || [])].map((x) => x.label.toLowerCase()));
  const A = set(a), B = set(b);
  return [...A].filter((x) => B.has(x));
}

function mockSwipe(me, candidates, asks) {
  return candidates.map((c) => {
    const shared = overlap(me, c);
    const r = seeded(me.id + c.id)();
    const score = clamp(2 + shared.length * 1.0 + r * 3.5, 0, 10);
    return { id: c.id, score: Number(score.toFixed(1)), ask: false,
      reason: shared.length ? `We'd both be into ${shared.slice(0, 2).join(" and ")}.` : `Not much overlap with what I need, but ${c.name.split(" ")[0]} seems kind.` };
  });
}
