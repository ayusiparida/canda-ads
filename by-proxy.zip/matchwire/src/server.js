import express from "express";
import { config } from "./config.js";
import { db } from "./db.js";
import { bus } from "./events.js";
import { getPerson, listPeople, listDates, getDate } from "./store.js";
import { addPerson, joinPool, readAndAnalyze, runSeason, isSeasonRunning } from "./pipeline.js";
import { rankFor, topCouples } from "./agents/rank.js";
import * as V from "./web/views.js";

const app = express();
app.use(express.urlencoded({ extended: false, limit: "200kb" }));
app.use(express.json({ limit: "200kb" }));
app.use(express.static("public", { maxAge: "1h" }));

const demoIds = () => db.prepare("SELECT id FROM people WHERE is_demo=1").all().map((r) => r.id);
const allIds = () => db.prepare("SELECT id FROM people").all().map((r) => r.id);
const scope = (demo) => (demo ? { ids: demoIds(), base: "/demo", demo: true } : { ids: allIds(), base: "", demo: false });
const isAdmin = (req) => config.adminToken && (req.query.token === config.adminToken || req.get("x-admin-token") === config.adminToken);

/* ---- pages ---- */
app.get("/", (req, res) => res.send(V.homePage({ people: listPeople() })));
app.get("/how", (req, res) => res.send(V.howPage()));

for (const demo of [false, true]) {
  const pre = demo ? "/demo" : "";
  if (demo) app.get("/demo", (req, res) => res.redirect("/demo/people"));
  app.get(`${pre}/people`, (req, res) => {
    const s = scope(demo);
    res.send(V.peoplePage({ people: listPeople({ demoOnly: demo }), ...s }));
  });
  app.get(`${pre}/people/:id`, (req, res) => {
    const s = scope(demo);
    const p = getPerson(req.params.id);
    if (!p || (demo && !p.is_demo)) return res.status(404).send(V.howPage());
    res.send(V.profilePage({ p, ranking: rankFor(p.id, s.ids), dates: listDates({ personId: p.id, scopeIds: s.ids }), people: listPeople({ demoOnly: demo }), ...s }));
  });
  app.get(`${pre}/dates`, (req, res) => {
    const s = scope(demo);
    res.send(V.datesPage({ dates: listDates({ scopeIds: s.ids }), people: listPeople({ demoOnly: demo }), season: !demo && isSeasonRunning(), ...s }));
  });
  app.get(`${pre}/dates/:id`, (req, res) => {
    const s = scope(demo);
    const d = getDate(req.params.id);
    if (!d || (demo && !(s.ids.includes(d.a_id) && s.ids.includes(d.b_id)))) return res.status(404).redirect(`${pre}/dates`);
    res.send(V.datePage({ d, A: getPerson(d.a_id), B: getPerson(d.b_id), ...s }));
  });
  app.get(`${pre}/rankings`, (req, res) => {
    const s = scope(demo);
    const people = listPeople({ demoOnly: demo });
    const rankings = Object.fromEntries(people.map((p) => [p.id, rankFor(p.id, s.ids)]));
    res.send(V.rankingsPage({ people, rankings, couples: topCouples(s.ids, 8), ...s }));
  });
}

/* ---- actions ---- */
const recentJoins = [];
app.post("/people", (req, res) => {
  const { linkedin, instagram, gender = "", open_to = "anyone", consent } = req.body;
  const fail = (error) => res.status(400).send(V.homePage({ people: listPeople(), error, values: req.body }));
  if (!consent) return fail("Please confirm these are your links or that this person agreed to be added.");
  const now = Date.now();
  while (recentJoins.length && now - recentJoins[0] > 3600_000) recentJoins.shift();
  if (recentJoins.length >= config.maxPublicJoinsPerHour) return fail("The site has hit its hourly limit for new people. Try again in a little while, or browse the demo.");
  try {
    const { id, existing } = addPerson({ linkedin, instagram, gender: ["man", "woman", "nonbinary"].includes(gender) ? gender : "", open_to: ["man", "woman", "nonbinary"].includes(open_to) ? open_to : "anyone" });
    if (!existing) { recentJoins.push(now); joinPool(id); }
    res.redirect(`/people/${id}`);
  } catch (e) { fail(e.message); }
});

app.post("/people/:id/retry", (req, res) => {
  const p = getPerson(req.params.id);
  if (!p || p.status !== "error") return res.redirect(`/people/${req.params.id}`);
  (p.is_demo ? readAndAnalyze(p.id) : joinPool(p.id));
  res.redirect(`/people/${p.id}`);
});

app.post("/people/:id/delete", (req, res) => {
  const p = getPerson(req.params.id);
  if (p && (!p.is_demo || isAdmin(req))) db.prepare("DELETE FROM people WHERE id=?").run(p.id);
  res.redirect("/people");
});

/* ---- live updates (Server-Sent Events) ---- */
app.get("/events", (req, res) => {
  res.set({ "content-type": "text/event-stream", "cache-control": "no-cache", connection: "keep-alive", "x-accel-buffering": "no" });
  res.flushHeaders();
  const send = (ev) => res.write(`data: ${JSON.stringify(ev)}\n\n`);
  bus.on("event", send);
  const ping = setInterval(() => res.write(": ping\n\n"), 20000);
  req.on("close", () => { bus.off("event", send); clearInterval(ping); });
});

/* ---- JSON API (same data the pages use) ---- */
app.get("/api/people/:id", (req, res) => {
  const p = getPerson(req.params.id);
  if (!p) return res.status(404).json({ error: "not found" });
  const { persona, ...rest } = p;
  res.json({ ...rest, ranking: rankFor(p.id, allIds()) });
});
app.get("/api/dates/:id", (req, res) => { const d = getDate(req.params.id); d ? res.json(d) : res.status(404).json({ error: "not found" }); });

/* ---- admin ---- */
app.get("/admin", (req, res) => {
  if (!isAdmin(req)) return res.status(403).send("Set ADMIN_TOKEN and pass ?token=");
  const counts = { people: allIds().length, demo: demoIds().length, dates: db.prepare("SELECT COUNT(*) n FROM dates").get().n };
  res.send(V.adminPage({ token: req.query.token, msg: req.query.msg, counts, running: isSeasonRunning() }));
});
app.post("/admin/bulk", async (req, res) => {
  if (!isAdmin(req)) return res.status(403).end();
  const added = [], errors = [];
  for (const line of String(req.body.lines || "").split(/\n/).map((l) => l.trim()).filter(Boolean)) {
    const [linkedin, instagram, gender = "", open_to = "anyone"] = line.split(/[\s,]+/);
    try { added.push(addPerson({ linkedin, instagram, gender, open_to, is_demo: 1 }).id); } catch (e) { errors.push(`${line}: ${e.message}`); }
  }
  (async () => { for (const id of added) await readAndAnalyze(id); })();
  res.redirect(`/admin?token=${encodeURIComponent(req.query.token)}&msg=${encodeURIComponent(`Added ${added.length}. ${errors.join(" | ")}`)}`);
});
app.post("/admin/season", (req, res) => {
  if (!isAdmin(req)) return res.status(403).end();
  runSeason(req.body.demo ? demoIds() : undefined).catch((e) => console.error(e));
  res.redirect(`/admin?token=${encodeURIComponent(req.query.token)}&msg=Season+started`);
});

app.listen(config.port, () => console.log(`By Proxy on :${config.port} · llm=${config.llmProvider} · linkedin=${config.linkedinProvider} · instagram=${config.instagramProvider}`));
