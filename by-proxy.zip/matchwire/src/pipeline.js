import { db } from "./db.js";
import { config } from "./config.js";
import { emit } from "./events.js";
import { id, pool } from "./util.js";
import { parseLinks, identityCheck } from "./sources/validate.js";
import { fetchSources } from "./sources/index.js";
import { analyzePerson, buildPersona } from "./agents/analyze.js";
import { swipe } from "./agents/swipe.js";
import { runDate, debrief } from "./agents/date.js";
import { getPerson, readyPeople, setStatus, compatible } from "./store.js";

const status = (pid, s, detail = "", error = null) => { setStatus(pid, s, detail, error); emit("person", { id: pid, status: s, detail, error }); };

/** Step 1: register a pair of links. Throws a readable error on bad input. */
export function addPerson({ linkedin, instagram, gender = "", open_to = "anyone", is_demo = 0 }) {
  const links = parseLinks(linkedin, instagram);
  const existing = db.prepare("SELECT id FROM people WHERE li_slug=? AND ig_handle=?").get(links.liSlug, links.igHandle);
  if (existing) return { id: existing.id, existing: true };
  const pid = id("p_");
  db.prepare(`INSERT INTO people (id, linkedin_url, instagram_url, li_slug, ig_handle, gender, open_to, is_demo)
    VALUES (?,?,?,?,?,?,?,?)`).run(pid, links.linkedinUrl, links.instagramUrl, links.liSlug, links.igHandle, gender, open_to, is_demo ? 1 : 0);
  emit("person", { id: pid, status: "queued" });
  return { id: pid, existing: false };
}

/** Steps 2-3: read both sources, then the agent analyzes the person. */
export async function readAndAnalyze(pid) {
  const p = getPerson(pid);
  try {
    status(pid, "fetching", "Reading LinkedIn and Instagram");
    const { linkedin, instagram, providers } = await fetchSources({ liSlug: p.li_slug, linkedinUrl: p.linkedin_url, igHandle: p.ig_handle });
    const save = db.prepare("INSERT OR REPLACE INTO sources (person_id, kind, provider, data_json) VALUES (?,?,?,?)");
    save.run(pid, "linkedin", providers.linkedin, JSON.stringify(linkedin));
    save.run(pid, "instagram", providers.instagram, JSON.stringify(instagram));
    db.prepare("UPDATE people SET name=?, photo_url=? WHERE id=?").run(linkedin.name || instagram.name || p.ig_handle, linkedin.photo || instagram.photo || "", pid);

    status(pid, "analyzing", `Agent is reading ${instagram.posts.length} posts and ${linkedin.experience.length} roles`);
    const identity = identityCheck(linkedin, instagram);
    const { analysis } = await analyzePerson(linkedin, instagram);
    const persona = buildPersona(linkedin.name || instagram.name, linkedin, analysis);
    db.prepare("INSERT OR REPLACE INTO profiles (person_id, analysis_json, persona, identity_json, model) VALUES (?,?,?,?,?)")
      .run(pid, JSON.stringify(analysis), persona, JSON.stringify(identity), config.llmProvider === "mock" ? "mock" : config.analysisModel);
    status(pid, "ready", "Profile ready");
    return true;
  } catch (e) {
    console.error(`[analyze ${pid}]`, e);
    status(pid, "error", "", e.message);
    return false;
  }
}

async function swipeFor(me, pool_) {
  const cands = pool_.filter((o) => compatible(me, o));
  const rows = await swipe(me, cands);
  const up = db.prepare("INSERT OR REPLACE INTO swipes (from_id, to_id, score, reason, ask) VALUES (?,?,?,?,?)");
  db.transaction(() => rows.forEach((r) => up.run(me.id, r.id, r.score, r.reason, r.ask ? 1 : 0)))();
  emit("swipes", { id: me.id, asks: rows.filter((r) => r.ask).map((r) => r.id) });
  return rows;
}

/** Step 4: one date, start to finish, streamed live. */
export async function goOnDate(aId, bId) {
  const a = getPerson(aId), b = getPerson(bId);
  const did = id("d_");
  db.prepare("INSERT INTO dates (id, a_id, b_id, status) VALUES (?,?,?,'live')").run(did, aId, bId);
  emit("date", { id: did, a: aId, b: bId, status: "live" });
  const transcript = [];
  try {
    const { plan } = await runDate(a, b, {
      onEvent: (ev) => {
        if (ev.kind === "plan") {
          db.prepare("UPDATE dates SET venue=?, venue_why=?, twist=? WHERE id=?").run(ev.plan.venue, ev.plan.why, ev.plan.twist, did);
          emit("date_plan", { id: did, plan: ev.plan });
        } else {
          transcript.push(ev.turn);
          db.prepare("UPDATE dates SET transcript_json=? WHERE id=?").run(JSON.stringify(transcript), did);
          emit("date_turn", { id: did, turn: ev.turn, n: transcript.length });
        }
      },
    });
    db.prepare("UPDATE dates SET status='debrief' WHERE id=?").run(did);
    emit("date", { id: did, status: "debrief" });
    const [da, db_] = await Promise.all([debrief(a, b, plan, transcript), debrief(b, a, plan, transcript)]);
    const ins = db.prepare(`INSERT OR REPLACE INTO debriefs (date_id, person_id, about_id, score, second_date, liked, worried, summary, moment, detail_json) VALUES (?,?,?,?,?,?,?,?,?,?)`);
    ins.run(did, aId, bId, da.score, da.second_date ? 1 : 0, da.liked, da.worried, da.summary, da.moment, JSON.stringify({ needs_check: da.needs_check }));
    ins.run(did, bId, aId, db_.score, db_.second_date ? 1 : 0, db_.liked, db_.worried, db_.summary, db_.moment, JSON.stringify({ needs_check: db_.needs_check }));
    db.prepare("UPDATE dates SET status='done', finished_at=datetime('now') WHERE id=?").run(did);
    emit("date", { id: did, status: "done", scores: [da.score, db_.score] });
  } catch (e) {
    console.error(`[date ${did}]`, e);
    db.prepare("UPDATE dates SET status='failed' WHERE id=?").run(did);
    emit("date", { id: did, status: "failed", error: e.message });
  }
  return did;
}

/** Pair people from mutual interest, then make sure everyone gets enough dates. */
export function planPairs(people, swipesByFrom, { min = config.minDatesPerPerson, max = config.maxDatesPerPerson } = {}) {
  const count = Object.fromEntries(people.map((p) => [p.id, 0]));
  const pairs = new Set(); const out = [];
  const s = (f, t) => swipesByFrom[f]?.find((r) => r.id === t);
  const mutual = (a, b) => ((s(a, b)?.score ?? 0) + (s(b, a)?.score ?? 0)) / 2;
  const add = (a, b, why) => {
    const k = [a, b].sort().join("|");
    if (a === b || pairs.has(k)) return false;
    pairs.add(k); count[a]++; count[b]++; out.push({ a, b, why }); return true;
  };
  const byId = Object.fromEntries(people.map((p) => [p.id, p]));
  const asks = [];
  for (const p of people) for (const r of swipesByFrom[p.id] || []) if (r.ask && byId[r.id]) {
    const back = s(r.id, p.id)?.ask;
    asks.push({ a: p.id, b: r.id, m: mutual(p.id, r.id) + (back ? 5 : 0), why: back ? "mutual ask" : "asked out" });
  }
  asks.sort((x, y) => y.m - x.m);
  for (const x of asks) if (count[x.a] < max && count[x.b] < max) add(x.a, x.b, x.why);
  for (const p of people) {
    const options = people.filter((o) => o.id !== p.id && compatible(p, o)).sort((x, y) => mutual(p.id, y.id) - mutual(p.id, x.id));
    for (const o of options) { if (count[p.id] >= min) break; if (count[o.id] < max + 1) add(p.id, o.id, "matchmaker pick"); }
  }
  return out;
}

let seasonRunning = false;
export const isSeasonRunning = () => seasonRunning;

/** Full season for a set of people: swipe → plan dates → date → debrief. */
export async function runSeason(ids) {
  if (seasonRunning) throw new Error("A season is already running.");
  seasonRunning = true;
  try {
    const people = readyPeople(ids);
    emit("season", { phase: "swiping", n: people.length });
    const swipesByFrom = {};
    await pool(people, config.llmConcurrency, async (p) => { swipesByFrom[p.id] = await swipeFor(p, people.filter((o) => o.id !== p.id)); });
    const pairs = planPairs(people, swipesByFrom);
    emit("season", { phase: "dating", dates: pairs.length });
    await pool(pairs, Math.max(2, Math.floor(config.llmConcurrency / 2)), (x) => goOnDate(x.a, x.b));
    const done = db.prepare("UPDATE people SET status='done', status_detail='Dates finished. Rankings ready.' WHERE id=? AND status='ready'");
    people.forEach((p) => done.run(p.id));
    emit("season", { phase: "done" });
    return pairs.length;
  } finally { seasonRunning = false; }
}

/** A newcomer (e.g. a grader's own links) joins the existing pool and goes on a few dates. */
export async function joinPool(pid) {
  const ok = await readAndAnalyze(pid);
  if (!ok) return;
  const me = getPerson(pid);
  const others = readyPeople().filter((o) => o.id !== pid);
  if (!others.length) { status(pid, "done", "Profile ready. No one else in the pool yet."); return; }
  status(pid, "swiping", `Agent is reading ${others.length} profiles`);
  const mine = await swipeFor(me, others);
  const eligible = others.filter((o) => compatible(me, o));
  await pool(eligible, config.llmConcurrency, (o) => swipeFor(o, [me]));
  const back = Object.fromEntries(db.prepare("SELECT from_id, score FROM swipes WHERE to_id=?").all(pid).map((r) => [r.from_id, r.score]));
  const picks = mine.map((r) => ({ ...r, m: (r.score + (back[r.id] ?? 0)) / 2 })).sort((a, b) => b.m - a.m).slice(0, config.joinDates);
  status(pid, "dating", `Going on ${picks.length} dates`);
  await pool(picks, 3, (r) => goOnDate(pid, r.id));
  status(pid, "done", "Dates finished. Rankings ready.");
}
