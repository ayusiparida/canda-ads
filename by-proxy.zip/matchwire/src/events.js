import { EventEmitter } from "node:events";
// In-process event bus. Pipeline code emits; the SSE endpoint relays to browsers.
export const bus = new EventEmitter();
bus.setMaxListeners(500);
export const emit = (type, payload) => bus.emit("event", { type, ...payload, at: Date.now() });
