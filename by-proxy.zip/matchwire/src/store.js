import { db, j } from "./db.js";

// Read helpers that assemble a person with their sources and analysis.
export function getPerson(id) {
  const p = db.prepare("SELECT * FROM people WHERE id=?").get(id);
  if (!p) return null;
  const prof = db.prepare("SELECT * FROM profiles WHERE person_id=?").get(id);
  const src = Object.fromEntries(db.prepare("SELECT kind, data_json, provider FROM sources WHERE person_id=?").all(id).map((r) => [r.kind, { ...j(r.data_json), _provider: r.provider }]));
  return {
    ...p, linkedin: src.linkedin || null, instagram: src.instagram || null,
    analysis: prof ? j(prof.analysis_json) : null, persona: prof?.persona || "",
    identity: prof ? j(prof.identity_json) : null,
    headline: src.linkedin?.headline || "",
  };
}

export function listPeople({ demoOnly = false } = {}) {
  const rows = db.prepare(`SELECT id FROM people ${demoOnly ? "WHERE is_demo=1" : ""} ORDER BY is_demo DESC, created_at ASC`).all();
  return rows.map((r) => getPerson(r.id));
}

export const readyPeople = (ids) => (ids ? ids.map(getPerson) : listPeople()).filter((p) => p && p.analysis && ["ready", "done", "swiping", "dating"].includes(p.status));

export function setStatus(id, status, detail = "", error = null) {
  db.prepare("UPDATE people SET status=?, status_detail=?, error=? WHERE id=?").run(status, detail, error, id);
}

export function getDate(id) {
  const d = db.prepare("SELECT * FROM dates WHERE id=?").get(id);
  if (!d) return null;
  const debriefs = db.prepare("SELECT * FROM debriefs WHERE date_id=?").all(id).map((x) => ({ ...x, detail: j(x.detail_json, {}) }));
  return { ...d, transcript: j(d.transcript_json, []), debriefs };
}

export function listDates({ personId, scopeIds } = {}) {
  let rows = db.prepare("SELECT * FROM dates ORDER BY created_at DESC").all();
  if (personId) rows = rows.filter((d) => d.a_id === personId || d.b_id === personId);
  if (scopeIds) { const s = new Set(scopeIds); rows = rows.filter((d) => s.has(d.a_id) && s.has(d.b_id)); }
  return rows.map((d) => getDate(d.id));
}

export const compatible = (a, b) => {
  const ok = (open, g) => !open || open === "anyone" || !g || open === g;
  return a.id !== b.id && ok(a.open_to, b.gender) && ok(b.open_to, a.gender);
};
