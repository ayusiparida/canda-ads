// Central config. Everything is overridable with environment variables.
export const config = {
  port: Number(process.env.PORT || 3000),
  dbPath: process.env.DB_PATH || "data/byproxy.db",

  // LLM
  llmProvider: process.env.LLM_PROVIDER || (process.env.ANTHROPIC_API_KEY ? "anthropic" : "mock"),
  anthropicKey: process.env.ANTHROPIC_API_KEY || "",
  analysisModel: process.env.ANALYSIS_MODEL || "claude-sonnet-5-5",
  dateModel: process.env.DATE_MODEL || "claude-haiku-5-5",
  llmConcurrency: Number(process.env.LLM_CONCURRENCY || 6),

  // Sources: "apify" | "fixture". Instagram can also use "graph" (official Business Discovery API).
  linkedinProvider: process.env.LINKEDIN_PROVIDER || (process.env.APIFY_TOKEN ? "apify" : "fixture"),
  instagramProvider: process.env.INSTAGRAM_PROVIDER || (process.env.APIFY_TOKEN ? "apify" : "fixture"),
  apifyToken: process.env.APIFY_TOKEN || "",
  apifyInstagramActor: process.env.APIFY_INSTAGRAM_ACTOR || "apify~instagram-profile-scraper",
  apifyLinkedinActor: process.env.APIFY_LINKEDIN_ACTOR || "dev_fusion~Linkedin-Profile-Scraper",
  igGraphToken: process.env.IG_GRAPH_TOKEN || "",
  igGraphUserId: process.env.IG_GRAPH_USER_ID || "",

  // Dating harness
  turnsPerDate: Number(process.env.TURNS_PER_DATE || 10),
  asksPerAgent: Number(process.env.ASKS_PER_AGENT || 4),
  minDatesPerPerson: Number(process.env.MIN_DATES || 5),
  maxDatesPerPerson: Number(process.env.MAX_DATES || 7),
  joinDates: Number(process.env.JOIN_DATES || 5),

  // Guards
  adminToken: process.env.ADMIN_TOKEN || "",
  maxPublicJoinsPerHour: Number(process.env.MAX_JOINS_PER_HOUR || 12),
};
