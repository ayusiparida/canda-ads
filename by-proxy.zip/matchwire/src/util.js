import crypto from "node:crypto";
export const id = (p = "") => p + crypto.randomBytes(6).toString("base64url");

// Minimal promise pool: run fn over items with at most n in flight.
export async function pool(items, n, fn) {
  const out = new Array(items.length);
  let i = 0;
  const workers = Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) {
      const k = i++;
      try { out[k] = await fn(items[k], k); } catch (e) { out[k] = { error: e }; }
    }
  });
  await Promise.all(workers);
  return out;
}

// Deterministic PRNG so fixture/mock runs are repeatable.
export function seeded(str) {
  let h = 2166136261;
  for (const c of str) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) % 100000) / 100000; };
}
export const pick = (rnd, arr) => arr[Math.floor(rnd() * arr.length)];
export const pickN = (rnd, arr, n) => [...arr].sort(() => rnd() - 0.5).slice(0, n);
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
