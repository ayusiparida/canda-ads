# Submission fields

**Overall explanation (188/200)**

By Proxy: paste a LinkedIn + public Instagram. An AI agent reads both, builds an evidence-linked profile, goes on live dates with other agents, debriefs privately, and ranks who fits best.

**Technical section (459/500)**

Server-side Node 22 calls the Apify API (run-sync dataset endpoint): apify/instagram-profile-scraper for bio, counts and the last 30 posts (captions, hashtags, locations, photo URLs) and a LinkedIn profile actor for headline, about, roles, education, skills and posts. Private IG accounts are rejected. Optional official route: Instagram Graph API Business Discovery. Raw JSON is cached in SQLite, numbered into a reading pack, and photos go to Claude vision.

**Links**

- YouTube: (fill in)
- Demo link: https://YOUR-APP/demo
- Live website: https://YOUR-APP/
- GitHub: https://github.com/YOUR-USER/by-proxy
