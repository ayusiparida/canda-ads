# By Proxy — agentic dating

Each person is represented by an AI agent. The agent reads **only** two sources, the person's LinkedIn and their public Instagram, writes an evidence-linked profile, then goes on real turn-by-turn dates with every other person's agent. Both agents debrief privately, and every person gets a ranking of who fits them best.

- **Live site:** paste a LinkedIn + public Instagram on the home page. Your agent is analyzed, swipes the whole pool, goes on 5 dates, and your ranking appears on your profile page (1–3 minutes).
- **Demo:** `/demo` is the frozen, already-run season of the opted-in roster.
- **How it works:** `/how` on the site, and below.

## Pipeline

```
links ─► validate ─► fetch (Apify / IG Graph) ─► identity check ─► analysis agent ─► persona
                                                                         │
                       ranking ◄── debriefs (both sides) ◄── dates ◄── swipe + pairing
```

1. **Validate.** Only `linkedin.com/in/…` and `instagram.com/<handle>` profile URLs are accepted, then normalized. Private Instagram accounts are rejected after fetch.
2. **Fetch.** `src/sources/`. LinkedIn and Instagram are scraped server-side via the Apify API (`run-sync-get-dataset-items`). Instagram can alternatively use the official Graph API Business Discovery endpoint (`INSTAGRAM_PROVIDER=graph`) for public Business/Creator accounts. Nothing besides these two profiles is ever read.
3. **Identity check.** `validate.js#identityCheck` scores whether the two links belong to the same person (name overlap, handle contains the name, cross-links in bios). Shown as a badge on the profile.
4. **Analysis.** `src/agents/analyze.js`. Both sources become a numbered *reading pack* (`LI:exp2`, `IG:post7`, …). The model reads the pack plus up to 6 post photos (vision) and returns needs, hobbies, interests, values, personality, lifestyle, communication style, humor, green flags, possible friction, conversation hooks, ideal first date, confidence and gaps. **Every item must cite source tags**, which the profile page links back to the exact post or role. It is instructed not to infer orientation, religion, ethnicity, health, politics or finances.
5. **Persona.** The analysis becomes the agent's system prompt: speak as the person, want what they need, never invent facts. Visible on each profile page.
6. **Swipe.** `src/agents/swipe.js`. Each agent reads every compatible card and scores fit 0–10 from its own person's needs, with a reason, and asks out its top 4.
7. **Pairing.** `pipeline.js#planPairs`: mutual asks first, then one-way asks, then a matchmaker fills gaps so everyone gets ≥5 dates (capped per person).
8. **The date.** `src/agents/date.js`. A planner picks a specific venue both would enjoy and writes one unscripted moment. The two agents alternate for 10 turns; each turn is `THOUGHT:` (private, never shown to the other agent) + `SAY:`. Each agent sees the conversation from its own side. The twist lands at the halfway point; the last two turns wind down. Turns stream live to the browser over SSE.
9. **Debrief.** Each agent privately reports to its own person: score, second date yes/no, liked, worried, the telling moment, and a yes/partly/no check of each of its person's needs.
10. **Ranking.** `src/agents/rank.js`. Dated pairs: `0.15·mean(swipes) + 0.65·√(debriefA × debriefB) + 0.20·second-date agreement`. Undated pairs: `0.6·mean(swipes)`. The geometric mean means one-sided chemistry can't reach the top.

Optional preferences: each person can set who they're open to dating; incompatible pairs are never swiped, dated or ranked. Nothing about orientation is inferred.

## Run it

```bash
npm install
cp .env.example .env   # add ANTHROPIC_API_KEY, APIFY_TOKEN, ADMIN_TOKEN
node --env-file=.env src/server.js
```

Without keys it runs fully offline in **mock mode** (fictional fixture profiles + scripted agent replies) so you can try every page:

```bash
npm run demo:fixtures                         # 26 synthetic people, ~76 dates, ~10s
DB_PATH=data/fixture.db npm start             # open http://localhost:3000/demo
npm test                                      # validation, pairing, full season, ranking
```

### Build the real demo

1. Put opted-in people in `data/people.csv` (see `data/people.example.csv`): `linkedin_url,instagram_url,gender,open_to`.
2. `node --env-file=.env scripts/seed.js` — fetches, analyzes, and runs a full season. Or use `/admin?token=…` to bulk-add and start a season from the browser.

### Deploy (Railway or Render)

Docker is included. Set the env vars, mount a volume, and set `DB_PATH=/data/byproxy.db`. Long-running dates are fine because it's a normal Node server (no serverless timeouts). Public joins are rate-limited (`MAX_JOINS_PER_HOUR`).

## Stack

Node 22 + Express, SQLite (better-sqlite3), server-rendered HTML + Server-Sent Events for live dates, Claude API (Sonnet-class for analysis, Haiku-class for swipes, dates and debriefs), Apify for profile fetching, optional Instagram Graph API.

## Privacy

Everyone in the demo opted in. The form requires confirming the links are yours or that the person agreed. Any non-demo person can be removed from their profile page, which deletes their sources, analysis, dates and ranking. Scraping LinkedIn is against LinkedIn's user agreement; this project keeps volumes tiny, only for consenting people, and the Instagram path can run entirely on Meta's official API.
