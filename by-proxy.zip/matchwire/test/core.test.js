import { test } from "node:test";
import assert from "node:assert/strict";
process.env.DB_PATH = ":memory:"; process.env.LLM_PROVIDER = "mock";
process.env.LINKEDIN_PROVIDER = "fixture"; process.env.INSTAGRAM_PROVIDER = "fixture";
const { parseLinks, identityCheck } = await import("../src/sources/validate.js");
const { planPairs, addPerson, readAndAnalyze, runSeason } = await import("../src/pipeline.js");
const { rankFor } = await import("../src/agents/rank.js");
const { db } = await import("../src/db.js");

test("accepts profile links and normalizes them", () => {
  const r = parseLinks("https://in.linkedin.com/in/Jane-Doe-12?trk=x", "https://instagram.com/jane.doe/?hl=en");
  assert.equal(r.liSlug, "jane-doe-12"); assert.equal(r.igHandle, "jane.doe");
  assert.equal(r.instagramUrl, "https://www.instagram.com/jane.doe/");
});
test("rejects non-profile links", () => {
  assert.throws(() => parseLinks("https://linkedin.com/company/acme", "https://instagram.com/a"), /profile link/);
  assert.throws(() => parseLinks("https://linkedin.com/in/a", "https://instagram.com/p/xyz"), /not a post/);
  assert.throws(() => parseLinks("https://evil.com/in/a", "https://instagram.com/a"), /linkedin\.com/);
});
test("identity check rewards matching names and cross-links", () => {
  const strong = identityCheck({ name: "Jane Doe", about: "", headline: "" }, { name: "Jane Doe", handle: "jane.doe", bio: "", externalUrl: "https://linkedin.com/in/jane" });
  const weak = identityCheck({ name: "Jane Doe", about: "", headline: "" }, { name: "Bob", handle: "bobby", bio: "", externalUrl: "" });
  assert.equal(strong.level, "strong"); assert.equal(weak.level, "weak");
});
test("pairing gives everyone at least the minimum number of dates", () => {
  const people = Array.from({ length: 10 }, (_, i) => ({ id: `p${i}`, open_to: "anyone", gender: "" }));
  const swipes = Object.fromEntries(people.map((p) => [p.id, people.filter((o) => o.id !== p.id).map((o, k) => ({ id: o.id, score: (k * 7) % 10, ask: k < 2 }))]));
  const pairs = planPairs(people, swipes, { min: 4, max: 6 });
  const count = {}; pairs.forEach(({ a, b }) => { count[a] = (count[a] || 0) + 1; count[b] = (count[b] || 0) + 1; });
  people.forEach((p) => assert.ok(count[p.id] >= 4, `${p.id} has ${count[p.id]}`));
  assert.equal(new Set(pairs.map(({ a, b }) => [a, b].sort().join())).size, pairs.length, "no duplicate pairs");
});
test("full season: analyze, date, and rank everyone (mock LLM)", async () => {
  const ids = [];
  for (let i = 0; i < 8; i++) ids.push(addPerson({ linkedin: `https://www.linkedin.com/in/test-person-${i}/`, instagram: `https://www.instagram.com/test.person${i}/`, is_demo: 1 }).id);
  for (const id of ids) assert.ok(await readAndAnalyze(id));
  const n = await runSeason(ids);
  assert.ok(n >= 8);
  const done = db.prepare("SELECT COUNT(*) n FROM dates WHERE status='done'").get().n;
  assert.equal(done, n);
  for (const id of ids) {
    const r = rankFor(id, ids);
    assert.equal(r.length, 7);
    assert.ok(r.some((x) => x.dated));
    for (let k = 1; k < r.length; k++) assert.ok(r[k - 1].fit >= r[k].fit);
  }
});
