// Live updates over Server-Sent Events. Pages re-fetch themselves and swap the live parts.
(() => {
  const live = document.querySelectorAll("[data-live-person],[data-live-date],[data-live-list]");
  if (!live.length || !window.EventSource) return;
  const es = new EventSource("/events");
  let timer = null;
  const refresh = (delay = 600) => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const html = await (await fetch(location.href, { headers: { "x-partial": "1" } })).text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const swap = (sel) => {
        const now = document.querySelectorAll(sel), next = doc.querySelectorAll(sel);
        now.forEach((el, i) => next[i] && (el.innerHTML = next[i].innerHTML));
      };
      // Profile pages change shape when analysis finishes, so reload the whole thing.
      const person = document.querySelector("[data-live-person]");
      const nextPerson = doc.querySelector("[data-live-person]");
      if (person && !nextPerson) return location.reload();
      if (person) swap("[data-live-person]");
      const chat = document.querySelector("[data-live-date]");
      if (chat) {
        const before = chat.querySelectorAll(".turn").length;
        swap("[data-live-date]"); swap(".debriefs");
        const turns = chat.querySelectorAll(".turn");
        for (let i = before; i < turns.length; i++) turns[i].classList.add("new");
        if (turns.length > before) turns[turns.length - 1].scrollIntoView({ behavior: "smooth", block: "center" });
        if (!doc.querySelector("[data-live-date]")) { chat.removeAttribute("data-live-date"); }
      }
      swap("[data-live-list]");
    }, delay);
  };
  es.onmessage = (m) => {
    const ev = JSON.parse(m.data);
    const person = document.querySelector("[data-live-person]");
    const chat = document.querySelector("[data-live-date]");
    if (person && ev.type === "person" && ev.id === person.dataset.livePerson) return refresh(100);
    if (chat && ev.id === chat.dataset.liveDate) return refresh(50);
    if (document.querySelector("[data-live-list]") && ["person", "date", "season"].includes(ev.type)) refresh(1500);
  };
})();
